using System.IO.Ports;
using System.Text;

namespace BangTai_ChieuCao;

internal interface IConveyorLink : IDisposable
{
    void Send(string line);
    void Poll(long now, Action<string> receive);
}

internal sealed class SerialLink : IConveyorLink
{
    private readonly SerialPort port;
    private readonly StringBuilder line = new(ConveyorProtocol.MaxLine);
    private bool discard;

    public SerialLink(string name)
    {
        port = new SerialPort(name, ConveyorProtocol.Baud, Parity.None, 8, StopBits.One)
        {
            NewLine = "\n",
            Handshake = Handshake.None,
            DtrEnable = false,
            RtsEnable = false,
            WriteTimeout = 150
        };
        try
        {
            port.Open();
        }
        catch
        {
            port.Dispose();
            throw;
        }
    }

    public void Send(string message) => port.WriteLine(message);

    public void Poll(long now, Action<string> receive)
    {
        foreach (char c in port.ReadExisting())
        {
            if (c == '\n')
            {
                if (!discard && line.Length > 0)
                    receive(line.ToString().TrimEnd('\r'));
                line.Clear();
                discard = false;
            }
            else if (!discard)
            {
                if (line.Length == ConveyorProtocol.MaxLine)
                {
                    line.Clear();
                    discard = true;
                }
                else
                {
                    line.Append(c);
                }
            }
        }
    }

    public void Dispose() => port.Dispose();
}
