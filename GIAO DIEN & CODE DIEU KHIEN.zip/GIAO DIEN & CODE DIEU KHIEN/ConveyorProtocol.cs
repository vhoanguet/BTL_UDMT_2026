using System.Globalization;

namespace BangTai_ChieuCao;

internal enum MachineState { Stopped, Homing, Ready, Running, Fault }
internal enum Grade { None, High, Mid, Low }
internal enum Command { Start, Stop, Home }

internal readonly record struct Counts(uint High, uint Mid, uint Low, uint? Fed = null)
{
    public ulong Total => (ulong)High + Mid + Low;
    public bool WentBackFrom(Counts previous) =>
        High < previous.High || Mid < previous.Mid || Low < previous.Low ||
        Fed < previous.Fed;

    public Counts Since(Counts baseline) =>
        new(High - baseline.High, Mid - baseline.Mid, Low - baseline.Low, Fed - (baseline.Fed ?? 0));
}

internal sealed record Snapshot(uint Session, MachineState State, Counts Counts,
    int Ir, int Home, int Servo, bool Motor, bool StopInput, bool Armed,
    uint RunSeconds, Grade LastGrade, string Fault);

internal static class ConveyorProtocol
{
    public const int Baud = 115200;
    public const string Hello = "HELLO HEIGHT1";
    public const int MaxLine = 240;

    public static bool TryState(string[] words, out Snapshot? state)
    {
        state = null;
        if (words.Length is not (15 or 16) ||
            words is not ["STATE", var session, var status, var high, var mid, var low,
            var ir, var home, var servo, var motor, var stop, var armed, var seconds,
            var grade, var fault, ..])
            return false;

        MachineState? machineState = status switch
        {
            "STOPPED" => MachineState.Stopped, "HOMING" => MachineState.Homing,
            "READY" => MachineState.Ready, "RUNNING" => MachineState.Running,
            "FAULT" => MachineState.Fault, _ => null
        };
        Grade? lastGrade = grade switch
        {
            "-" => Grade.None, "HIGH" => Grade.High, "MID" => Grade.Mid,
            "LOW" => Grade.Low, _ => null
        };
        if (machineState is null || lastGrade is null ||
            !Number(session, out uint id) || id == 0 ||
            !Number(high, out uint h) || !Number(mid, out uint m) || !Number(low, out uint l) ||
            !Mask(ir, out int irMask) || !Mask(home, out int homeMask) ||
            !Mask(servo, out int servoMask) || !Bit(motor) || !Bit(stop) || !Bit(armed) ||
            !Number(seconds, out uint runSeconds) || !Token(fault))
            return false;

        uint? fed = null;
        if (words.Length == 16)
        {
            if (!Number(words[15], out uint fedCount))
                return false;
            fed = fedCount;
        }

        state = new Snapshot(id, machineState.Value, new Counts(h, m, l, fed), irMask, homeMask,
            servoMask, motor == "1", stop == "1", armed == "1", runSeconds, lastGrade.Value, fault);
        return true;
    }

    public static bool Number(string value, out uint number) =>
        uint.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out number);

    public static bool Token(string value) => value == "-" ||
        (value.Length is >= 1 and <= 48 &&
         value.All(c => c is >= 'A' and <= 'Z' or >= '0' and <= '9' or '_'));

    private static bool Bit(string value) => value is "0" or "1";

    private static bool Mask(string value, out int mask)
    {
        bool parsed = Number(value, out uint number) && number <= 15;
        mask = parsed ? (int)number : 0;
        return parsed;
    }
}
