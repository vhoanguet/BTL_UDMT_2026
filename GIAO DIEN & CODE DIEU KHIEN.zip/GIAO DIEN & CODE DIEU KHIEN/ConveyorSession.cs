using System.Diagnostics;
using System.Globalization;

namespace BangTai_ChieuCao;

internal sealed class ConveyorSession : IDisposable
{
    private sealed record Pending(uint Id, Command Command, long SentAt, bool Accepted = false);

    private readonly Stopwatch clock = Stopwatch.StartNew();
    private IConveyorLink? link;
    private Pending? pending;
    private uint session;
    private uint request;
    private long opened;
    private long heartbeat;
    private long received;
    private Counts baseline;

    public bool Connected => link is not null;
    public string Source { get; private set; } = "—";
    public Snapshot? Data { get; private set; }
    public DateTimeOffset? Updated { get; private set; }
    public Counts Batch => Data?.Counts.Since(baseline) ?? default;
    public bool CanStop => Connected && session != 0;
    public bool CanHome => pending is null && Data is
    {
        Armed: true, StopInput: false, Motor: false, Servo: 0,
        State: MachineState.Stopped or MachineState.Ready, Fault: "-"
    };
    public bool CanStart => CanHome && Data is { State: MachineState.Ready, Home: 15 };
    public bool CanReset => pending is null && Data is
    {
        Motor: false, Servo: 0, State: MachineState.Stopped or MachineState.Ready or MachineState.Fault
    };
    public string? PendingLabel => pending is { } value ? CommandLabel(value.Command) : null;
    public event Action<string, string>? Activity;
    public event Action? Changed;

    public void Open(IConveyorLink connection, string source, long? time = null)
    {
        if (Connected)
            throw new InvalidOperationException("Kết nối hiện tại chưa đóng.");
        link = connection;
        Source = source;
        opened = time ?? clock.ElapsedMilliseconds;
        heartbeat = opened;
        Log("Kết nối", $"Đã mở {source}. Đang chờ ESP32 xác nhận HEIGHT1.");
        Changed?.Invoke();
    }

    public void Poll(long? time = null)
    {
        if (link is null)
            return;
        long now = time ?? clock.ElapsedMilliseconds;
        try
        {
            link.Poll(now, line => Receive(line, now));
            if (now >= heartbeat)
            {
                link.Send(session == 0 ? ConveyorProtocol.Hello : FormattableString.Invariant($"PING {session}"));
                heartbeat = now + (session == 0 ? 900 : 450);
            }

            if (Data is null && now - opened >= 6000)
                Close("Không nhận được dữ liệu HEIGHT1 hợp lệ trong 6 giây.");
            else if (Data is not null && now - received >= 2500)
                Close("Mất dữ liệu ESP32 quá 2,5 giây. Đã đóng kết nối.");
            else if (pending is { } command && now - command.SentAt >= 2500)
                Close($"Hết thời gian xác nhận lệnh {CommandLabel(command.Command)}. Đã đóng kết nối.");
        }
        catch (Exception error) when (PortError(error))
        {
            Close($"Lỗi kết nối. {error.Message}");
        }
    }

    public void Send(Command command, long? time = null)
    {
        bool allowed = command switch
        {
            Command.Start => CanStart,
            Command.Home => CanHome,
            _ => CanStop
        };
        if (!allowed || link is null ||
            (command == Command.Stop && pending is { Command: Command.Stop }))
            return;

        try
        {
            uint id = ++request;
            link.Send(FormatCommand(id, command));
            pending = new Pending(id, command, time ?? clock.ElapsedMilliseconds);
            Log("Điều khiển", $"Đã gửi lệnh {CommandLabel(command)}.");
            Changed?.Invoke();
        }
        catch (Exception error) when (PortError(error))
        {
            Close($"Gửi lệnh thất bại. {error.Message}");
        }
    }

    public void ResetBatch()
    {
        if (!CanReset || Data is null)
            return;
        baseline = Data.Counts;
        Log("Thống kê", "Đã đặt mốc bộ đếm trên máy tính.");
        Changed?.Invoke();
    }

    public void Close(string reason)
    {
        var connection = link;
        if (connection is null)
            return;
        link = null;
        try
        {
            if (CanSendStopOnClose())
            {
                connection.Send(FormatCommand(++request, Command.Stop));
                Log("Điều khiển", "Đã gửi lệnh Dừng máy khi đóng kết nối.");
            }
        }
        catch (Exception error) when (PortError(error))
        {
            Log("Kết nối", "Không gửi được lệnh Dừng máy khi đóng cổng.");
        }
        finally
        {
            try { connection.Dispose(); }
            catch (Exception error) when (PortError(error)) { Log("Kết nối", "Cổng COM đã mất."); }
        }

        Data = null;
        Updated = null;
        session = 0;
        request = 0;
        pending = null;
        baseline = default;
        Log("Kết nối", reason);
        Source = "—";
        Changed?.Invoke();
    }

    private bool CanSendStopOnClose() => session != 0 && (Data is null || Data.Motor ||
        Data.Servo != 0 || Data.State is MachineState.Running or MachineState.Homing || pending is not null);

    internal static bool PortError(Exception error) =>
        error is IOException or UnauthorizedAccessException or InvalidOperationException or
            ArgumentException or TimeoutException or System.Security.SecurityException;

    private void Receive(string line, long now)
    {
        string[] words = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (words is ["HELLO", "HEIGHT1", var id] &&
            ConveyorProtocol.Number(id, out uint reportedSession) && reportedSession != 0)
        {
            if (session != reportedSession)
            {
                if (session != 0)
                    opened = now;
                Log("Kết nối", session == 0 ? "Đã xác nhận giao thức HEIGHT1." : "ESP32 đã khởi động lại.");
                session = reportedSession;
                Data = null;
                Updated = null;
                pending = null;
                baseline = default;
                heartbeat = now;
                Changed?.Invoke();
            }
            return;
        }

        if (session == 0)
            return;

        if (ConveyorProtocol.TryState(words, out Snapshot? next) && next is not null && next.Session == session)
        {
            Snapshot? previous = Data;
            if (previous is not null && next.Counts.WentBackFrom(previous.Counts))
            {
                baseline = default;
                Log("Thống kê", "Bộ đếm ESP32 đã bắt đầu lại.");
            }

            Data = next;
            received = now;
            Updated = DateTimeOffset.UtcNow;
            if (pending?.Accepted == true)
                pending = null;

            if (next.State != previous?.State || next.Fault != previous?.Fault)
                Log("Trạng thái", StateLabel(next.State) + (next.Fault == "-" ? "." : $" · {next.Fault}"));
            if (previous is not null)
            {
                if (next.Counts.Fed is uint fed && previous.Counts.Fed is uint before && fed > before)
                    Log("Cấp phôi", $"+{fed - before} phôi qua IR1.");
                LogIncrement("Cao", next.Counts.High, previous.Counts.High);
                LogIncrement("Trung", next.Counts.Mid, previous.Counts.Mid);
                LogIncrement("Thấp", next.Counts.Low, previous.Counts.Low);
                if (next.StopInput != previous.StopInput)
                    Log("Ngõ STOP", next.StopInput ? "Đang kích hoạt." : "Đã nhả.");
            }
            Changed?.Invoke();
            return;
        }

        if (pending is not { } waiting ||
            words.Length < 4 || !ConveyorProtocol.Number(words[1], out uint replySession) ||
            replySession != session || !ConveyorProtocol.Number(words[2], out uint replyId) ||
            replyId != waiting.Id || words[3] != WireCommand(waiting.Command))
            return;

        if (words is ["ACK", _, _, _] && !waiting.Accepted)
        {
            pending = waiting with { Accepted = true };
            Log("Điều khiển", $"ESP32 đã nhận lệnh {CommandLabel(waiting.Command)}.");
        }
        else if (words is ["ERR", _, _, _, var reason] && ConveyorProtocol.Token(reason))
        {
            pending = null;
            Log("Điều khiển", $"ESP32 từ chối lệnh {CommandLabel(waiting.Command)} · {reason}.");
        }
        Changed?.Invoke();
    }

    private void LogIncrement(string grade, uint next, uint previous)
    {
        if (next > previous)
            Log("Sản phẩm", $"+{next - previous} phôi loại {grade.ToLowerInvariant()} đã phân loại.");
    }

    private string FormatCommand(uint id, Command command) =>
        FormattableString.Invariant($"CMD {session} {id} {WireCommand(command)}");

    private void Log(string group, string message) => Activity?.Invoke(group, message);
    private static string WireCommand(Command command) => command.ToString().ToUpperInvariant();

    public static string CommandLabel(Command command) => command switch
    {
        Command.Start => "Chạy máy", Command.Stop => "Dừng máy", _ => "Về gốc"
    };

    public static string StateLabel(MachineState state) => state switch
    {
        MachineState.Homing => "Đang về gốc", MachineState.Ready => "Sẵn sàng",
        MachineState.Running => "Hệ thống đang chạy", MachineState.Fault => "Lỗi thiết bị", _ => "Đã dừng"
    };

    public static string RunTime(uint seconds) => string.Create(CultureInfo.InvariantCulture,
        $"{seconds / 3600:00}:{seconds / 60 % 60:00}:{seconds % 60:00}");

    public void Dispose() => Close("Đã đóng kết nối.");
}
