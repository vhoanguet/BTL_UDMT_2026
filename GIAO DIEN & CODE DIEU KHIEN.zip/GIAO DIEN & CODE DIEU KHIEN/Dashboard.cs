using System.Drawing.Imaging;
using System.IO.Ports;

namespace BangTai_ChieuCao;

internal sealed class Dashboard : Form
{
    private readonly ConveyorSession session = new();
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 100 };
    private readonly ToolTip tips = new();
    private readonly ComboBox ports = new()
    {
        DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Theme.Panel,
        ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = Theme.Body,
        DrawMode = DrawMode.OwnerDrawFixed, ItemHeight = 20,
        AccessibleName = "Cổng COM", Width = 126
    };
    private readonly Label connection = LabelOf("NGOẠI TUYẾN", Theme.Strong, Theme.Muted);
    private readonly Label status = LabelOf("", Theme.Section);
    private readonly Label detail = LabelOf("", Theme.Small, Theme.Muted);
    private readonly Label runtime = LabelOf("—", Theme.Tabular);
    private readonly Label updated = LabelOf("—", Theme.Tabular);
    private readonly Label grade = LabelOf("—", Theme.Strong);
    private readonly Label[] counts = new Label[5];
    private readonly Label[] ratios = new Label[3];
    private readonly Panel statusBar = new() { Dock = DockStyle.Fill, BackColor = Theme.Panel };
    private readonly Panel statusStripe = new() { Dock = DockStyle.Left, Width = 4 };
    private readonly DistributionChart chart = new() { Dock = DockStyle.Fill, BackColor = Theme.Panel };
    private readonly Lamp[] ir =
        [new("IR 1 · Đếm phôi"), new("IR 2 · Cao"), new("IR 3 · Trung"), new("IR 4 · Thấp (cuối)")];
    private readonly Lamp[] home = [new("KW12 1"), new("KW12 2"), new("KW12 3"), new("KW12 4")];
    private readonly Lamp[] servo = [new("S1 · Cấp phôi"), new("S2 · Gạt cao"), new("S3 · Gạt trung"), new("S4 · Gạt thấp")];
    private readonly Lamp motor = new("Động cơ băng");
    private readonly Lamp stopInput = new("Ngõ STOP");
    private readonly Button scan = ButtonOf("Quét", width: 70);
    private readonly Button connect = ButtonOf("Kết nối ESP32", Theme.Blue, 126);
    private readonly Button disconnect = ButtonOf("Ngắt", width: 70);
    private readonly Button start = ButtonOf("Chạy máy", Theme.Green);
    private readonly Button stop = ButtonOf("Dừng máy", Theme.Red);
    private readonly Button homeButton = ButtonOf("Về gốc", Theme.Blue);
    private readonly Button reset = ButtonOf("Reset bộ đếm");
    private readonly Button report = ButtonOf("Xuất báo cáo", width: 114);
    private readonly Button csv = ButtonOf("Xuất CSV", width: 88);
    private readonly DataGridView grid = new();
    private readonly LinkedList<ActivityEntry> history = new();
    private readonly DashboardLayout dashboardLayout;
    private string offlineText = "Chọn cổng COM rồi bấm Kết nối ESP32.";
    private const string NoPort = "Chọn COM";
    private string? SelectedPort => ports.SelectedItem is string name && name != NoPort ? name : null;

    public Dashboard()
    {
        Text = "Băng tải phân loại chiều cao";
        Font = Theme.Body;
        ForeColor = Theme.Text;
        BackColor = Theme.Canvas;
        // Pixel-based fonts and layout rows share the same units at mixed monitor DPI.
        AutoScaleMode = AutoScaleMode.None;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1040, 710);
        ClientSize = DashboardLayout.NormalSize;
        DoubleBuffered = true;

        SuspendLayout();
        dashboardLayout = new DashboardLayout(BuildLayout());
        dashboardLayout.Resize(ClientSize);
        BindActions();
        ScanPorts();
        RefreshData();
        ResumeLayout(performLayout: true);
    }

    protected override void OnClientSizeChanged(EventArgs e)
    {
        base.OnClientSizeChanged(e);
        if (!Disposing)
            dashboardLayout?.Resize(ClientSize);
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        var area = Screen.FromControl(this).WorkingArea;
        Size minimum = SizeFromClientSize(new Size(1005, 675));
        MinimumSize = new Size(Math.Min(minimum.Width, area.Width), Math.Min(minimum.Height, area.Height));
        Size = new Size(Math.Min(Width, area.Width), Math.Min(Height, area.Height));
    }

    private TableLayoutPanel BuildLayout()
    {
        TableLayoutPanel layout = Table(1, 6);
        layout.Dock = DockStyle.None;
        layout.Padding = new Padding(20, 11, 20, 14);
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 57));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 94));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 222));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(layout);

        TableLayoutPanel header = Table(2, 2);
        header.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        header.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 75));
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        header.Controls.Add(LabelOf("Băng tải phân loại chiều cao", Theme.Title), 0, 0);
        header.Controls.Add(LabelOf("Điều khiển và giám sát qua ESP32", Theme.Body, Theme.Muted), 0, 1);
        connection.TextAlign = ContentAlignment.MiddleRight;
        header.Controls.Add(connection, 1, 0);
        header.SetRowSpan(connection, 2);
        layout.Controls.Add(header, 0, 0);

        Panel connectionPanel = new() { Dock = DockStyle.Fill };
        connectionPanel.BackColor = Theme.Panel;
        connectionPanel.Padding = new Padding(12, 6, 6, 6);
        connectionPanel.Margin = new Padding(0, 0, 0, 9);
        Label comLabel = LabelOf("USB–UART", Theme.Strong, Theme.Blue);
        comLabel.Size = new Size(93, 34);
        comLabel.Dock = DockStyle.None;
        comLabel.Margin = new Padding(0, 0, 4, 0);
        ports.Margin = new Padding(0, 4, 8, 0);
        connectionPanel.Controls.Add(Flow(comLabel, ports, scan, connect, disconnect));
        layout.Controls.Add(connectionPanel, 0, 1);

        TableLayoutPanel metrics = Table(counts.Length, 1);
        for (int i = 0; i < counts.Length; i++)
            metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / counts.Length));
        string[] names = ["CAO", "TRUNG", "THẤP", "TỔNG", "ĐÃ CẤP"];
        Color[] colors = [.. Theme.Grades, Theme.Blue, Theme.Muted];
        for (int i = 0; i < counts.Length; i++)
        {
            Panel tile = new()
            {
                Dock = DockStyle.Fill, BackColor = Theme.Panel,
                Margin = new Padding(0, 0, i < counts.Length - 1 ? 10 : 0, 10)
            };
            TableLayoutPanel stack = Table(1, 2);
            stack.Padding = new Padding(14, 5, 10, 6);
            stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
            stack.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            stack.Controls.Add(LabelOf(names[i], Theme.Strong, colors[i]), 0, 0);
            counts[i] = LabelOf("—", Theme.Metric);
            counts[i].AccessibleName = names[i];
            stack.Controls.Add(counts[i], 0, 1);
            tile.Controls.Add(stack);
            tile.Controls.Add(new Panel { Dock = DockStyle.Top, Height = 3, BackColor = colors[i] });
            metrics.Controls.Add(tile, i, 0);
        }
        layout.Controls.Add(metrics, 0, 2);

        statusBar.Margin = new Padding(0, 0, 0, 10);
        TableLayoutPanel stateGrid = Table(3, 2);
        stateGrid.Padding = new Padding(11, 3, 8, 4);
        stateGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        stateGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 135));
        stateGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 123));
        stateGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        stateGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        stateGrid.Controls.Add(status, 0, 0);
        stateGrid.Controls.Add(detail, 0, 1);
        stateGrid.Controls.Add(LabelOf("Thời gian chạy", Theme.Small, Theme.Muted), 1, 0);
        stateGrid.Controls.Add(runtime, 1, 1);
        stateGrid.Controls.Add(LabelOf("Cập nhật · UTC+7", Theme.Small, Theme.Muted), 2, 0);
        stateGrid.Controls.Add(updated, 2, 1);
        statusBar.Controls.Add(stateGrid);
        statusBar.Controls.Add(statusStripe);
        layout.Controls.Add(statusBar, 0, 3);

        TableLayoutPanel work = Table(3, 1);
        work.Margin = new Padding(0, 0, 0, 10);
        work.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        work.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 29));
        work.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 41));
        work.Controls.Add(ChartPanel(), 0, 0);
        work.Controls.Add(ControlPanel(), 1, 0);
        work.Controls.Add(IoPanel(), 2, 0);
        layout.Controls.Add(work, 0, 4);
        layout.Controls.Add(HistoryPanel(), 0, 5);
        return layout;
    }

    private Control ChartPanel()
    {
        TableLayoutPanel panel = SectionPanel("Tỷ lệ phân loại", marginRight: 10);
        TableLayoutPanel body = Table(2, 1);
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
        body.Controls.Add(chart, 0, 0);
        TableLayoutPanel meta = Table(1, 6);
        meta.Padding = new Padding(4, 10, 0, 0);
        string[] labels = ["Cao", "Trung", "Thấp"];
        for (int i = 0; i < labels.Length; i++)
        {
            meta.RowStyles.Add(new RowStyle(SizeType.Absolute, 27));
            ratios[i] = LabelOf("", Theme.Strong, Theme.Grades[i]);
            ratios[i].Tag = labels[i];
            meta.Controls.Add(ratios[i], 0, i);
        }
        meta.RowStyles.Add(new RowStyle(SizeType.Absolute, 7));
        meta.RowStyles.Add(new RowStyle(SizeType.Absolute, 20));
        meta.RowStyles.Add(new RowStyle(SizeType.Absolute, 27));
        meta.Controls.Add(LabelOf("Loại gần nhất", Theme.Small, Theme.Muted), 0, 4);
        meta.Controls.Add(grade, 0, 5);
        body.Controls.Add(meta, 1, 0);
        panel.Controls.Add(body, 0, 1);
        return panel;
    }

    private Control ControlPanel()
    {
        TableLayoutPanel panel = SectionPanel("Điều khiển", marginRight: 10);
        TableLayoutPanel buttons = Table(2, 4);
        buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        buttons.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        buttons.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        buttons.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
        buttons.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        buttons.Padding = new Padding(0, 3, 0, 0);
        foreach (var button in new[] { start, stop, homeButton, reset })
        {
            button.Dock = DockStyle.Fill;
            button.Margin = new Padding(0, 0, 7, 7);
        }
        buttons.Controls.Add(start, 0, 0);
        buttons.Controls.Add(stop, 1, 0);
        buttons.Controls.Add(homeButton, 0, 1);
        buttons.Controls.Add(reset, 1, 1);
        motor.Dock = stopInput.Dock = DockStyle.Fill;
        buttons.Controls.Add(motor, 0, 2);
        buttons.Controls.Add(stopInput, 1, 2);
        var launchNote = LabelOf("Về gốc trước khi chạy máy.", Theme.Small, Theme.Muted);
        buttons.Controls.Add(launchNote, 0, 3);
        buttons.SetColumnSpan(launchNote, 2);
        panel.Controls.Add(buttons, 0, 1);
        return panel;
    }

    private Control IoPanel()
    {
        TableLayoutPanel panel = SectionPanel("Giám sát tín hiệu");
        TableLayoutPanel matrix = Table(3, 6);
        matrix.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35));
        matrix.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));
        matrix.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 37));
        matrix.RowStyles.Add(new RowStyle(SizeType.Absolute, 23));
        matrix.Controls.Add(LabelOf("CẢM BIẾN IR", Theme.Strong, Theme.Muted), 0, 0);
        matrix.Controls.Add(LabelOf("HÀNH TRÌNH", Theme.Strong, Theme.Muted), 1, 0);
        matrix.Controls.Add(LabelOf("SERVO", Theme.Strong, Theme.Muted), 2, 0);
        for (int i = 0; i < ir.Length; i++)
        {
            matrix.RowStyles.Add(new RowStyle(SizeType.Absolute, 29));
            ir[i].Dock = home[i].Dock = servo[i].Dock = DockStyle.Fill;
            matrix.Controls.Add(ir[i], 0, i + 1);
            matrix.Controls.Add(home[i], 1, i + 1);
            matrix.Controls.Add(servo[i], 2, i + 1);
        }
        matrix.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var key = LabelOf("Xanh · bật     Đỏ · tắt     Gạch · chờ dữ liệu", Theme.Small, Theme.Muted);
        matrix.Controls.Add(key, 0, 5);
        matrix.SetColumnSpan(key, 3);
        panel.Controls.Add(matrix, 0, 1);
        return panel;
    }

    private Control HistoryPanel()
    {
        TableLayoutPanel panel = Table(1, 2);
        panel.BackColor = Theme.Panel;
        panel.Padding = new Padding(12, 7, 12, 8);
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Panel heading = new() { Dock = DockStyle.Fill, Margin = Padding.Empty };
        var actions = Flow(csv, report);
        actions.Dock = DockStyle.Right;
        actions.Width = 213;
        heading.Controls.Add(LabelOf("Nhật ký hoạt động", Theme.Section));
        heading.Controls.Add(actions);
        panel.Controls.Add(heading, 0, 0);

        grid.Dock = DockStyle.Fill;
        grid.Margin = new Padding(0, 3, 0, 0);
        grid.BorderStyle = BorderStyle.None;
        grid.BackgroundColor = Theme.Panel;
        grid.GridColor = Theme.Border;
        grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.ColumnHeadersHeight = 28;
        grid.RowTemplate.Height = 27;
        grid.RowHeadersVisible = false;
        grid.EnableHeadersVisualStyles = false;
        grid.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
        {
            BackColor = Theme.Raised, ForeColor = Theme.Muted, Font = Theme.Strong,
            Padding = new Padding(7, 0, 0, 0)
        };
        grid.DefaultCellStyle = new DataGridViewCellStyle
        {
            BackColor = Theme.Panel, ForeColor = Theme.Text, Font = Theme.Small,
            SelectionBackColor = Theme.Selection, SelectionForeColor = Theme.Text,
            Padding = new Padding(7, 0, 0, 0)
        };
        grid.AlternatingRowsDefaultCellStyle.BackColor = Theme.AlternateRow;
        grid.AllowUserToAddRows = grid.AllowUserToDeleteRows = grid.AllowUserToResizeRows = false;
        grid.ReadOnly = true;
        grid.MultiSelect = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        AddLogColumn("time", "Giờ · UTC+7", 120);
        AddLogColumn("source", "Nguồn", 112);
        AddLogColumn("category", "Nhóm", 130);
        AddLogColumn("message", "Nội dung", null);
        panel.Controls.Add(grid, 0, 1);
        return panel;
    }

    private void AddLogColumn(string key, string title, int? width)
    {
        var column = new DataGridViewTextBoxColumn
        {
            Name = key, HeaderText = title, SortMode = DataGridViewColumnSortMode.NotSortable,
            AutoSizeMode = width.HasValue ? DataGridViewAutoSizeColumnMode.None : DataGridViewAutoSizeColumnMode.Fill
        };
        if (width.HasValue)
            column.Width = width.Value;
        grid.Columns.Add(column);
    }

    private void BindActions()
    {
        session.Changed += RefreshData;
        session.Activity += AddActivity;
        ports.SelectedIndexChanged += (_, _) => RefreshData();
        ports.DrawItem += (_, e) =>
        {
            bool selected = (e.State & DrawItemState.Selected) != 0;
            using var background = new SolidBrush(selected ? Theme.Selection : Theme.Panel);
            e.Graphics.FillRectangle(background, e.Bounds);
            string label = e.Index >= 0 ? ports.GetItemText(ports.Items[e.Index]) ?? NoPort : NoPort;
            TextRenderer.DrawText(e.Graphics, label, ports.Font, e.Bounds,
                ports.Enabled && label != NoPort ? Theme.Text : Theme.Muted,
                TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
            e.DrawFocusRectangle();
        };
        timer.Tick += (_, _) => session.Poll();
        Shown += (_, _) => timer.Start();
        scan.Click += (_, _) => ScanPorts();
        connect.Click += (_, _) => Connect();
        disconnect.Click += (_, _) => session.Close("Đã ngắt cổng COM.");
        start.Click += (_, _) => session.Send(Command.Start);
        stop.Click += (_, _) => session.Send(Command.Stop);
        homeButton.Click += (_, _) => session.Send(Command.Home);
        reset.Click += (_, _) => session.ResetBatch();
        report.Click += (_, _) => SaveExport(html: true);
        csv.Click += (_, _) => SaveExport(html: false);
        tips.SetToolTip(ports, "USB–UART · 115200 baud · 8N1");
        tips.SetToolTip(reset, "Đặt mốc cho bộ đếm trên màn hình. Số liệu gốc vẫn lưu ở ESP32.");
        tips.SetToolTip(start, "Cần trạng thái Sẵn sàng và đủ 4 công tắc về gốc.");
        tips.SetToolTip(stop, "Gửi lệnh dừng qua cổng COM.");
        FormClosing += (_, _) =>
        {
            timer.Stop();
            session.Close("Đã đóng kết nối.");
        };
    }

    private void ScanPorts()
    {
        if (session.Connected)
            return;
        string? selected = SelectedPort;
        try
        {
            string[] names = SerialPort.GetPortNames()
                .OrderBy(name => name.Length > 3 && int.TryParse(name.AsSpan(3), out int index) ? index : int.MaxValue)
                .ToArray();
            ports.Items.Clear();
            ports.Items.AddRange(names);
            if (names.Length == 0)
            {
                ports.Items.Add(NoPort);
                ports.SelectedIndex = 0;
                offlineText = "Chưa tìm thấy cổng COM. Cắm USB–UART rồi bấm Quét.";
            }
            else
            {
                ports.SelectedItem = selected;
                if (ports.SelectedIndex < 0)
                    ports.SelectedIndex = 0;
                offlineText = "Chọn cổng COM rồi bấm Kết nối ESP32.";
            }
        }
        catch (Exception error) when (ConveyorSession.PortError(error))
        {
            AddActivity("Kết nối", $"Không quét được cổng COM. {error.Message}");
        }
        RefreshData();
    }

    private void Connect()
    {
        if (session.Connected || SelectedPort is not string name)
            return;
        try
        {
            session.Open(new SerialLink(name), name);
        }
        catch (Exception error) when (ConveyorSession.PortError(error))
        {
            AddActivity("Kết nối", $"Không mở được {name}. {error.Message}");
            RefreshData();
        }
    }

    private void RefreshData()
    {
        Snapshot? data = session.Data;
        Counts batch = session.Batch;
        ulong[] values = [batch.High, batch.Mid, batch.Low, batch.Total];
        for (int i = 0; i < values.Length; i++)
            counts[i].Text = data is null ? "—" : values[i].ToString("N0");
        counts[^1].Text = batch.Fed?.ToString("N0") ?? "—";
        for (int i = 0; i < ratios.Length; i++)
            ratios[i].Text = $"{ratios[i].Tag}    " + (batch.Total == 0 ? "—" : $"{(double)values[i] / batch.Total:P0}");
        chart.UpdateData(batch with { Fed = null }, data is not null);
        grade.Text = GradeLabel(data?.LastGrade ?? Grade.None);
        connection.Text = !session.Connected ? "●  NGOẠI TUYẾN" :
            data is null ? $"●  {session.Source} · ĐANG XÁC NHẬN" : $"●  {session.Source} · ĐÃ KẾT NỐI";
        connection.ForeColor = !session.Connected ? Theme.Muted :
            data is null ? Theme.Amber : Theme.Blue;
        status.Text = data is not null ? ConveyorSession.StateLabel(data.State) :
            session.Connected ? "Đang chờ dữ liệu ESP32" : "Chưa kết nối ESP32";
        statusStripe.BackColor = status.ForeColor = data?.State switch
        {
            MachineState.Running or MachineState.Ready => Theme.Green,
            MachineState.Homing => Theme.Blue, MachineState.Fault => Theme.Red, _ => Theme.Muted
        };
        detail.Text = session.PendingLabel is string pending ? $"Đang xác nhận lệnh {pending}…" :
            data is null ? (session.Connected ? "Đang xác nhận giao thức HEIGHT1." : offlineText) :
            data.Fault != "-" ? $"Mã lỗi · {data.Fault}" :
            data.StopInput ? "Ngõ STOP đang kích hoạt." :
            !data.Armed ? "Firmware chưa cho phép chuyển động." : "Phân loại theo tín hiệu IR";
        runtime.Text = data is null ? "—" : ConveyorSession.RunTime(data.RunSeconds);
        updated.Text = session.Updated is { } stamp ? ActivityEntry.Utc7(stamp).ToString("HH:mm:ss") : "—";
        bool legacy = data is { Counts.Fed: null };
        ir[0].Text = legacy ? "IR 1 · Cấp phôi" : "IR 1 · Đếm phôi";
        servo[1].Text = legacy ? "S2 · Chuyển" : "S2 · Gạt cao";
        servo[2].Text = legacy ? "S3 · Gạt cao" : "S3 · Gạt trung";
        servo[3].Text = legacy ? "S4 · Gạt trung" : "S4 · Gạt thấp";
        UpdateLamps(ir, data?.Ir);
        UpdateLamps(home, data?.Home);
        UpdateLamps(servo, data?.Servo);
        motor.Active = data?.Motor;
        stopInput.Active = data?.StopInput;
        ports.Enabled = scan.Enabled = !session.Connected;
        connect.Enabled = !session.Connected && SelectedPort is not null;
        disconnect.Enabled = session.Connected;
        start.Enabled = session.CanStart;
        stop.Enabled = session.CanStop;
        homeButton.Enabled = session.CanHome;
        reset.Enabled = session.CanReset;
        report.Enabled = data is not null;
        csv.Enabled = history.Count != 0;
    }

    private static void UpdateLamps(Lamp[] lights, int? mask)
    {
        for (int i = 0; i < lights.Length; i++)
            lights[i].Active = mask is int bits ? (bits & (1 << i)) != 0 : null;
    }

    private void AddActivity(string group, string message)
    {
        if (group == "Kết nối")
            offlineText = message;
        var entry = new ActivityEntry(DateTimeOffset.UtcNow, session.Source, group, message);
        history.AddFirst(entry);
        grid.Rows.Insert(0, entry.LocalTime.ToString("HH:mm:ss"), entry.Source, entry.Group, entry.Message);
        if (history.Count > 1000)
        {
            history.RemoveLast();
            grid.Rows.RemoveAt(grid.Rows.Count - 1);
        }
        grid.ClearSelection();
        csv.Enabled = true;
    }

    private void SaveExport(bool html)
    {
        using var dialog = new SaveFileDialog
        {
            Filter = html ? "Báo cáo HTML (*.html)|*.html" : "Nhật ký CSV (*.csv)|*.csv",
            FileName = $"BangTai_{ActivityEntry.Utc7(DateTimeOffset.UtcNow):yyyyMMdd_HHmmss}" + (html ? ".html" : ".csv"),
            AddExtension = true,
            OverwritePrompt = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK)
            return;

        try
        {
            if (html)
            {
                if (session.Data is not { } data)
                {
                    MessageBox.Show(this, "Kết nối đã kết thúc. Có thể xuất nhật ký bằng nút Xuất CSV.",
                        Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                Exports.Report(dialog.FileName, session.Source, session.Batch, data, session.Updated, history);
            }
            else
            {
                Exports.Csv(dialog.FileName, history);
            }
            AddActivity("Xuất tệp", $"Đã lưu {Path.GetFileName(dialog.FileName)}.");
        }
        catch (Exception error) when (ConveyorSession.PortError(error))
        {
            MessageBox.Show(this, error.Message, "Không lưu được tệp", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    internal static string GradeLabel(Grade product) => product switch
    {
        Grade.High => "Cao", Grade.Mid => "Trung", Grade.Low => "Thấp", _ => "—"
    };

    private static TableLayoutPanel Table(int columns, int rows) => new()
    {
        Dock = DockStyle.Fill, ColumnCount = columns, RowCount = rows,
        GrowStyle = TableLayoutPanelGrowStyle.FixedSize, Margin = Padding.Empty
    };

    private static TableLayoutPanel SectionPanel(string title, int marginRight = 0)
    {
        var panel = Table(1, 2);
        panel.BackColor = Theme.Panel;
        panel.Margin = new Padding(0, 0, marginRight, 0);
        panel.Padding = new Padding(13, 8, 10, 8);
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        panel.Controls.Add(LabelOf(title, Theme.Section), 0, 0);
        return panel;
    }

    private static Label LabelOf(string text, Font font, Color? color = null) => new()
    {
        Text = text, Dock = DockStyle.Fill, Font = font, ForeColor = color ?? Theme.Text,
        TextAlign = ContentAlignment.MiddleLeft, UseMnemonic = false,
        AutoEllipsis = true, Margin = Padding.Empty
    };

    private static Button ButtonOf(string text, Color? accent = null, int width = 114)
    {
        return new DashboardButton(accent)
        {
            Text = text, Width = width, Height = 32, Font = Theme.Strong, FlatStyle = FlatStyle.Flat,
            UseVisualStyleBackColor = false, Margin = new Padding(0, 0, 5, 0)
        };
    }

    private static FlowLayoutPanel Flow(params Control[] controls)
    {
        var panel = new FlowLayoutPanel { Margin = Padding.Empty, Dock = DockStyle.Fill, WrapContents = false };
        panel.Controls.AddRange(controls);
        return panel;
    }

    internal void SavePreview(string path, Size? clientSize = null)
    {
        ShowInTaskbar = false;
        Opacity = 0;
        Show();
        timer.Stop();
        if (clientSize is { } size)
            ClientSize = size;
        Application.DoEvents();
        using var frame = new Bitmap(ClientSize.Width, ClientSize.Height);
        using (var background = Graphics.FromImage(frame))
            background.Clear(BackColor);
        Control layout = Controls[0];
        layout.DrawToBitmap(frame, layout.Bounds);
        frame.Save(path, ImageFormat.Png);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Dispose();
            session.Dispose();
            tips.Dispose();
        }
        base.Dispose(disposing);
        if (disposing)
            dashboardLayout?.Dispose();
    }
}
