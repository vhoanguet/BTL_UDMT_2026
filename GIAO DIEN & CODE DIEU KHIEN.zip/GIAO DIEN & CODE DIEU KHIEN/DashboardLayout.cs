namespace BangTai_ChieuCao;

internal sealed class DashboardLayout : IDisposable
{
    public static readonly Size NormalSize = new(1240, 780);

    private readonly TableLayoutPanel content;
    private readonly List<Control> controls = new();
    private readonly List<Action<Scale>> adjustments = new();
    private Scale current = new(1f);

    public DashboardLayout(TableLayoutPanel content)
    {
        this.content = content;
        Track(content);
    }

    public void Resize(Size client)
    {
        if (client.Width <= 0 || client.Height <= 0)
            return;

        float fit = Math.Min((float)client.Width / NormalSize.Width, (float)client.Height / NormalSize.Height);
        float factor = Math.Max(1f, MathF.Floor(fit * 100) / 100);
        int width = Math.Min(client.Width, (int)Math.Round(NormalSize.Width * factor));
        var bounds = new Rectangle((client.Width - width) / 2, 0, width, client.Height);
        if (factor == current.Factor)
        {
            content.Bounds = bounds;
            return;
        }

        Scale previous = current;
        current = new Scale(factor);
        foreach (Control control in controls)
            control.SuspendLayout();
        try
        {
            foreach (var adjust in adjustments)
                adjust(current);
            content.Bounds = bounds;
        }
        finally
        {
            foreach (Control control in controls)
                control.ResumeLayout(performLayout: true);
            previous.Dispose();
        }
    }

    private void Track(Control control)
    {
        controls.Add(control);
        Font font = control.Font;
        Size size = control.Size;
        Padding padding = control.Padding;
        Padding margin = control.Margin;
        DockStyle dock = control.Dock;

        // Always scale from the original design values so repeated resizing has no rounding drift.
        adjustments.Add(scale =>
        {
            control.Font = scale.FontOf(font);
            control.Padding = scale.Insets(padding);
            control.Margin = scale.Insets(margin);
            if (control == content)
                return;
            switch (dock)
            {
                case DockStyle.None:
                    control.Size = new Size(scale.Px(size.Width), scale.Px(size.Height));
                    break;
                case DockStyle.Left or DockStyle.Right:
                    control.Width = scale.Px(size.Width);
                    break;
                case DockStyle.Top or DockStyle.Bottom:
                    control.Height = scale.Px(size.Height);
                    break;
            }
        });

        switch (control)
        {
            case TableLayoutPanel table:
                foreach (RowStyle row in table.RowStyles)
                {
                    float height = row.Height;
                    if (row.SizeType == SizeType.Absolute)
                        adjustments.Add(scale => row.Height = scale.Px(height));
                }
                foreach (ColumnStyle column in table.ColumnStyles)
                {
                    float width = column.Width;
                    if (column.SizeType == SizeType.Absolute)
                        adjustments.Add(scale => column.Width = scale.Px(width));
                }
                break;
            case ComboBox combo:
                int itemHeight = combo.ItemHeight;
                adjustments.Add(scale => combo.ItemHeight = scale.Px(itemHeight));
                break;
            case DistributionChart chart:
                Font unit = chart.UnitFont;
                adjustments.Add(scale => chart.UnitFont = scale.FontOf(unit));
                break;
            case DataGridView grid:
                TrackGrid(grid);
                break;
        }

        if (control is Panel)
        {
            foreach (Control child in control.Controls)
                Track(child);
        }
    }

    private void TrackGrid(DataGridView grid)
    {
        int headerHeight = grid.ColumnHeadersHeight;
        int rowHeight = grid.RowTemplate.Height;
        Font headerFont = grid.ColumnHeadersDefaultCellStyle.Font ?? grid.Font;
        Font rowFont = grid.DefaultCellStyle.Font ?? grid.Font;
        Padding headerPadding = grid.ColumnHeadersDefaultCellStyle.Padding;
        Padding rowPadding = grid.DefaultCellStyle.Padding;
        var columns = grid.Columns.Cast<DataGridViewColumn>()
            .Where(column => column.AutoSizeMode == DataGridViewAutoSizeColumnMode.None)
            .Select(column => (Column: column, Width: column.Width))
            .ToArray();

        adjustments.Add(scale =>
        {
            grid.ColumnHeadersDefaultCellStyle.Font = scale.FontOf(headerFont);
            grid.DefaultCellStyle.Font = scale.FontOf(rowFont);
            grid.ColumnHeadersDefaultCellStyle.Padding = scale.Insets(headerPadding);
            grid.DefaultCellStyle.Padding = scale.Insets(rowPadding);
            grid.ColumnHeadersHeight = scale.Px(headerHeight);
            grid.RowTemplate.Height = scale.Px(rowHeight);
            foreach (var (column, width) in columns)
                column.Width = scale.Px(width);
            foreach (DataGridViewRow row in grid.Rows)
                row.Height = grid.RowTemplate.Height;
        });
    }

    public void Dispose() => current.Dispose();

    private sealed class Scale(float factor) : IDisposable
    {
        private readonly Dictionary<Font, Font> fonts = new();
        public float Factor { get; } = factor;

        public int Px(float value) => (int)Math.Round(value * Factor);
        public Padding Insets(Padding value) => new(Px(value.Left), Px(value.Top), Px(value.Right), Px(value.Bottom));

        public Font FontOf(Font original)
        {
            if (Factor == 1f)
                return original;
            if (!fonts.TryGetValue(original, out Font? font))
            {
                font = new Font(original.FontFamily, original.Size * Factor, original.Style, original.Unit);
                fonts.Add(original, font);
            }
            return font;
        }

        public void Dispose()
        {
            foreach (Font font in fonts.Values)
                font.Dispose();
        }
    }
}
