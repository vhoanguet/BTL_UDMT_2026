using System.Drawing.Drawing2D;

namespace BangTai_ChieuCao;

internal static class Theme
{
    public static readonly Color Canvas = Color.FromArgb(239, 244, 249);
    public static readonly Color Panel = Color.White;
    public static readonly Color Raised = Color.FromArgb(229, 237, 246);
    public static readonly Color Border = Color.FromArgb(185, 200, 216);
    public static readonly Color AlternateRow = Color.FromArgb(246, 249, 252);
    public static readonly Color Selection = Color.FromArgb(218, 234, 250);
    public static readonly Color Muted = Color.FromArgb(72, 89, 110);
    public static readonly Color Text = Color.FromArgb(24, 40, 58);
    public static readonly Color Blue = Color.FromArgb(15, 93, 158);
    public static readonly Color Green = Color.FromArgb(16, 114, 65);
    public static readonly Color Red = Color.FromArgb(175, 38, 52);
    public static readonly Color Amber = Color.FromArgb(131, 86, 0);
    public static readonly Color[] Grades = [Color.FromArgb(166, 64, 17), Amber, Green];

    public static readonly Font Small = new("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
    public static readonly Font Body = new("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
    public static readonly Font Strong = new("Segoe UI Semibold", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
    public static readonly Font Section = new("Segoe UI Semibold", 17f, FontStyle.Regular, GraphicsUnit.Pixel);
    public static readonly Font Title = new("Segoe UI Semibold", 32f, FontStyle.Regular, GraphicsUnit.Pixel);
    public static readonly Font Metric = new("Segoe UI Semibold", 39f, FontStyle.Regular, GraphicsUnit.Pixel);
    public static readonly Font Tabular = new("Consolas", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
}

internal sealed class DashboardButton(Color? accent) : Button
{
    protected override void OnPaint(PaintEventArgs e)
    {
        bool filled = Enabled && accent.HasValue;
        Color fill = filled ? accent!.Value : Enabled ? Theme.Raised : Theme.Panel;
        if (Enabled && ClientRectangle.Contains(PointToClient(Cursor.Position)))
            fill = filled ? ControlPaint.Dark(fill, 0.1f) : Theme.Selection;

        e.Graphics.Clear(fill);
        if (!filled)
            ControlPaint.DrawBorder(e.Graphics, ClientRectangle, Theme.Border, ButtonBorderStyle.Solid);
        TextRenderer.DrawText(e.Graphics, Text, Font, ClientRectangle,
            Enabled ? (filled ? Color.White : Theme.Text) : Theme.Muted,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
            TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis);
        if (Focused && ShowFocusCues)
            ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(ClientRectangle, -4, -4));
    }
}

internal sealed class Lamp : Control
{
    private bool? active;

    public Lamp(string name)
    {
        Text = name;
        Font = Theme.Small;
        TabStop = false;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
    }

    public bool? Active
    {
        get => active;
        set
        {
            if (active == value)
                return;
            active = value;
            RefreshAccessibleName();
            Invalidate();
        }
    }

    private void RefreshAccessibleName() => AccessibleName =
        Text + (active == true ? " đang bật" : active == false ? " đang tắt" : " chờ dữ liệu");

    protected override void OnTextChanged(EventArgs e)
    {
        base.OnTextChanged(e);
        RefreshAccessibleName();
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        int diameter = Math.Min(Height - 4, Math.Max(9, (int)Math.Round(Font.Height * 0.75)));
        if (diameter < 6)
            return;
        int x = Math.Max(2, diameter / 6);
        int y = (Height - diameter) / 2;
        int inset = Math.Max(2, diameter / 4);
        Color color = active switch { true => Theme.Green, false => Theme.Red, _ => Theme.Muted };
        using var fill = new SolidBrush(Color.FromArgb(active == true ? 60 : 34, color));
        using var pen = new Pen(color, Math.Max(1f, diameter / 12f));
        e.Graphics.FillEllipse(fill, x, y, diameter, diameter);
        e.Graphics.DrawEllipse(pen, x, y, diameter, diameter);
        if (active == true)
        {
            using var bright = new SolidBrush(color);
            e.Graphics.FillEllipse(bright, x + inset, y + inset, diameter - 2 * inset, diameter - 2 * inset);
        }
        else if (active is null)
        {
            e.Graphics.DrawLine(pen, x + inset, y + diameter / 2, x + diameter - inset, y + diameter / 2);
        }
        int textX = x + diameter + Math.Max(5, diameter / 2);
        TextRenderer.DrawText(e.Graphics, Text, Font,
            new Rectangle(textX, 0, Math.Max(0, Width - textX), Height), Theme.Text,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
            TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
    }
}

internal sealed class DistributionChart : Control
{
    private Counts counts;
    private bool hasData;

    public DistributionChart()
    {
        AccessibleRole = AccessibleRole.Graphic;
        Font = Theme.Section;
        SetStyle(ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
    }

    public Font UnitFont { get; set; } = Theme.Small;

    public void UpdateData(Counts value, bool available)
    {
        if (counts == value && hasData == available)
            return;
        counts = value;
        hasData = available;
        AccessibleName = $"Phân bố. Cao {counts.High}. Trung {counts.Mid}. Thấp {counts.Low}.";
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        float diameter = Math.Min(Width - Font.Size, Height - UnitFont.Size);
        if (diameter < 30)
            return;
        var circle = new RectangleF((Width - diameter) / 2, (Height - diameter) / 2, diameter, diameter);
        using var outline = new SolidBrush(Theme.Raised);
        e.Graphics.FillEllipse(outline, circle);
        if (hasData && counts.Total != 0)
        {
            uint[] values = [counts.High, counts.Mid, counts.Low];
            float angle = -90;
            for (int i = 0; i < values.Length; i++)
            {
                if (values[i] == 0)
                    continue;
                float sweep = (float)(360d * values[i] / counts.Total);
                using var brush = new SolidBrush(Theme.Grades[i]);
                e.Graphics.FillPie(brush, circle.X, circle.Y, circle.Width, circle.Height, angle, sweep);
                angle += sweep;
            }
        }
        float thickness = diameter * 0.15f;
        circle.Inflate(-thickness, -thickness);
        using var center = new SolidBrush(BackColor);
        e.Graphics.FillEllipse(center, circle);
        int numberHeight = Font.Height + 3;
        int unitHeight = UnitFont.Height + 1;
        var number = new Rectangle(0, (Height - numberHeight - unitHeight) / 2, Width, numberHeight);
        var unit = new Rectangle(0, number.Bottom, Width, unitHeight);
        const TextFormatFlags flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
                                      TextFormatFlags.NoPadding | TextFormatFlags.SingleLine;
        TextRenderer.DrawText(e.Graphics, hasData ? counts.Total.ToString("N0") : "—",
            Font, number, Theme.Text, flags);
        TextRenderer.DrawText(e.Graphics, "phôi", UnitFont, unit, Theme.Muted, flags);
    }
}
