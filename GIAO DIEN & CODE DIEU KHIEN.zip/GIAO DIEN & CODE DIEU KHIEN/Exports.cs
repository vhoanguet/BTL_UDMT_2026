using System.Globalization;
using System.Net;
using System.Text;

namespace BangTai_ChieuCao;

internal sealed record ActivityEntry(DateTimeOffset Time, string Source, string Group, string Message)
{
    public DateTimeOffset LocalTime => Utc7(Time);
    public static DateTimeOffset Utc7(DateTimeOffset value) => value.ToOffset(TimeSpan.FromHours(7));
}

internal static class Exports
{
    private static readonly UTF8Encoding ExcelUtf8 = new(encoderShouldEmitUTF8Identifier: true);

    public static void Csv(string path, IEnumerable<ActivityEntry> history)
    {
        using var writer = new StreamWriter(path, append: false, ExcelUtf8);
        writer.WriteLine("Thời gian (UTC+7),Nguồn,Nhóm,Nội dung");
        foreach (var entry in history.Reverse())
            writer.WriteLine(string.Join(",", Cell(entry.LocalTime.ToString("yyyy-MM-dd HH:mm:ss")),
                Cell(entry.Source), Cell(entry.Group), Cell(entry.Message)));
    }

    public static void Report(string path, string source, Counts counts, Snapshot data,
        DateTimeOffset? updated, IEnumerable<ActivityEntry> history)
    {
        using var writer = new StreamWriter(path, append: false, ExcelUtf8);
        writer.WriteLine("""
            <!doctype html><html lang="vi"><meta charset="utf-8">
            <title>Báo cáo phân loại chiều cao</title>
            <style>
            body{font:15px "Segoe UI",sans-serif;color:#182c42;margin:32px auto;max-width:1040px;padding:0 16px}
            table{border-collapse:collapse;width:100%;margin:16px 0 28px}
            td,th{padding:8px 12px;text-align:left;border-bottom:1px solid #d5e0e9}
            th{background:#edf5fb} h1,h2{color:#143f5a}
            </style>
            <h1>Báo cáo phân loại chiều cao</h1>
            """);
        writer.WriteLine($"<p>Nguồn <strong>{Html(source)}</strong> · {Html(ConveyorSession.StateLabel(data.State))}</p>");
        writer.WriteLine($"<p>Thời gian chạy {ConveyorSession.RunTime(data.RunSeconds)} · Cập nhật " +
            $"{(updated is { } time ? ActivityEntry.Utc7(time).ToString("dd/MM/yyyy HH:mm:ss") : "—")} (UTC+7)</p>");
        if (counts.Fed is uint fed)
            writer.WriteLine($"<p>Đã cấp qua IR1 <strong>{fed}</strong></p>");
        writer.WriteLine("<table><tr><th>Loại phôi</th><th>Số lượng</th><th>Tỷ lệ</th></tr>");
        (string name, uint value)[] grades = [("Cao", counts.High), ("Trung", counts.Mid), ("Thấp", counts.Low)];
        foreach (var (name, value) in grades)
        {
            string ratio = counts.Total == 0 ? "—" : ((double)value / counts.Total).ToString("P1", CultureInfo.InvariantCulture);
            writer.WriteLine($"<tr><td>{name}</td><td>{value}</td><td>{ratio}</td></tr>");
        }
        writer.WriteLine($"<tr><th>Tổng</th><td>{counts.Total}</td><td>—</td></tr></table>");
        writer.WriteLine("<h2>Nhật ký hoạt động</h2><table><tr><th>Giờ (UTC+7)</th><th>Nguồn</th><th>Nhóm</th><th>Nội dung</th></tr>");
        foreach (var entry in history.Reverse())
            writer.WriteLine($"<tr><td>{entry.LocalTime:dd/MM/yyyy HH:mm:ss}</td><td>{Html(entry.Source)}</td>" +
                $"<td>{Html(entry.Group)}</td><td>{Html(entry.Message)}</td></tr>");
        writer.WriteLine("</table></html>");
    }

    private static string Cell(string value)
    {
        if (value.TrimStart() is [('=' or '+' or '-' or '@'), ..] || value.StartsWith('\t') || value.StartsWith('\r'))
            value = "'" + value;
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }

    private static string Html(string value) => WebUtility.HtmlEncode(value);
}
