#pragma once
#include <stdint.h>

namespace height {

// Leave false until input levels, motor stage and all four axes are verified on the bench.
constexpr bool Commissioned = false;

constexpr uint8_t IrPins[] = {36, 39, 34, 35};
// LM358 sensor is nominally active-high. Configure for the measured ESP32-side levels.
constexpr bool IrActiveHigh[] = {true, true, true, true};
constexpr uint8_t HomePins[] = {4, 5, 18, 19};
constexpr uint8_t StopPin = 33;      // SW1 to GND, active-low with pull-up
constexpr uint8_t MotorPin = 23;     // Active-high PC817 / MOSFET stage

enum Axis : uint8_t { Feed, HighGate, MidGate, LowGate, AxisCount };

struct AxisConfig {
  uint8_t pin;
  uint16_t neutralUs, extendUs, retractUs;
  uint32_t extendMs, returnMs;
};

constexpr uint32_t GateExtendMs = 1200;
constexpr uint32_t FeedIntervalMs = 5000; // Minimum time between S1 launches.

// Confirm neutral, direction and S1 travel for the actual continuous servos.
constexpr AxisConfig Axes[AxisCount] = {
  {25, 1500, 1600, 1400, 450, 2200},
  {26, 1500, 1600, 1400, GateExtendMs, 1800},
  {27, 1500, 1600, 1400, GateExtendMs, 1800},
  {32, 1500, 1600, 1400, GateExtendMs, 1800},
};

constexpr uint32_t Baud = 115200;
constexpr uint32_t DebounceMs = 20;
constexpr uint32_t LinkTimeoutMs = 1500;
constexpr uint32_t WatchdogMs = 2000;
constexpr uint32_t StatusPeriodMs = 250;
constexpr uint32_t ReleaseMs = 200;
constexpr uint32_t FeedClearMs = 1800;
constexpr uint32_t ClearMs = 2500;

constexpr bool validAxes() {
  for (const auto &axis : Axes) {
    if (axis.neutralUs < 1300 || axis.neutralUs > 1700 ||
        axis.extendUs < 1000 || axis.extendUs > 2000 ||
        axis.retractUs < 1000 || axis.retractUs > 2000 ||
        !((axis.extendUs > axis.neutralUs && axis.retractUs < axis.neutralUs) ||
          (axis.extendUs < axis.neutralUs && axis.retractUs > axis.neutralUs)) ||
        axis.extendMs < ReleaseMs || axis.returnMs == 0)
      return false;
  }
  return true;
}

static_assert(validAxes(), "Check servo pulses and travel limits.");
}
