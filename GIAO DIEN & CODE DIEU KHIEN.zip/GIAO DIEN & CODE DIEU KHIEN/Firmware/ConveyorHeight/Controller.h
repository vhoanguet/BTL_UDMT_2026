#pragma once
#include "Config.h"

namespace height {

constexpr uint8_t channelMask(uint8_t index) { return 1U << index; }
constexpr uint8_t FeedIr = channelMask(Feed);
constexpr uint8_t StationIrs = channelMask(HighGate) | channelMask(MidGate) | channelMask(LowGate);
constexpr uint8_t AllHome = 0x0f;

struct Inputs {
  uint8_t ir = 0, rawIr = 0, home = 0, rawHome = 0;
  bool stop = false, settled = false;
  bool homeAt(uint8_t axis) const { return (home & rawHome & channelMask(axis)) != 0; }
  uint8_t stations() const { return (ir | rawIr) & StationIrs; }
};

struct Outputs {
  int8_t servo[AxisCount]{}; // +1 extend, -1 retract, 0 neutral
  bool motor = false;
};

enum class State { Stopped, Homing, Ready, Running, Fault };
enum class Grade : uint8_t { None = Feed, High = HighGate, Mid = MidGate, Low = LowGate };

class Controller {
public:
  explicit Controller(bool commissioned) : commissioned_(commissioned) {}

  State state() const { return state_; }
  const char *faultCode() const { return fault_; }
  Grade lastGrade() const { return last_; }
  uint32_t count(Grade grade) const { return counts_[static_cast<uint8_t>(grade)]; }
  uint32_t fedCount() const { return fedCount_; }
  uint32_t runSeconds() const {
    uint64_t seconds = runMs_ / 1000U;
    return seconds > UINT32_MAX ? UINT32_MAX : static_cast<uint32_t>(seconds);
  }
  const Outputs &outputs() const { return output_; }
  bool armed(const Inputs &input) const { return commissioned_ && !hardwareFault_ && input.settled; }
  bool fresh(uint32_t now) const { return linked_ && now - lastPing_ < LinkTimeoutMs; }

  void latchHomeContact(uint8_t axis) {
    if (state_ == State::Homing && axis == homeAxis_) homeContact_ = true;
    if (state_ == State::Running && strokes_[axis].phase == Phase::Retracting)
      strokes_[axis].homeContact = true;
  }

  void handshake(uint32_t now) {
    if (moving() || state_ == State::Ready) stop(now);
    linked_ = false;
  }

  void ping(uint32_t now) { lastPing_ = now; linked_ = true; }

  void stop(uint32_t now) {
    output_ = {};
    if (!hardwareFault_) {
      fault_ = "-";
      changeState(State::Stopped, now);
    }
  }

  void hardwareFailure(const char *code, uint32_t now) {
    if (hardwareFault_) return;
    hardwareFault_ = true;
    fail(code, now);
  }

  const char *requestHome(const Inputs &input, uint32_t now) {
    if (const char *denial = readyForCommand(input, now)) return denial;
    if (state_ != State::Stopped && state_ != State::Ready) return "NOT_READY";
    homeAxis_ = 0;
    homeContact_ = false;
    changeState(State::Homing, now);
    return nullptr;
  }

  const char *start(const Inputs &input, uint32_t now) {
    if (const char *denial = readyForCommand(input, now)) return denial;
    if (state_ != State::Ready || (input.home & input.rawHome) != AllHome) return "NOT_READY";
    if ((input.ir | input.rawIr) & FeedIr) return "FEED_OCCUPIED";
    for (auto &stroke : strokes_) stroke = {};
    latchedIr_ = 0;
    lastFeedLaunch_ = now - FeedIntervalMs;
    changeState(State::Running, now);
    return nullptr;
  }

  void tick(const Inputs &input, uint32_t now) {
    accountTime(now);
    output_ = {};
    if (input.stop) {
      if (state_ != State::Fault && state_ != State::Stopped) stop(now);
      return;
    }
    if (state_ == State::Fault || state_ == State::Stopped) return;
    if (!fresh(now)) {
      if (moving()) fail("PC_LINK_LOST", now);
      else stop(now);
      return;
    }
    if (state_ == State::Homing) {
      tickHome(input, now);
      return;
    }

    if (state_ == State::Running) tickRun(input, now);
    else if (input.home != AllHome) fail("HOME_LOST", now);
  }

private:
  enum class Phase { Idle, Extending, Retracting, Clearing };
  struct Stroke {
    Phase phase = Phase::Idle;
    uint32_t since = 0;
    bool released = false, homeContact = false;
  };

  const bool commissioned_;
  bool hardwareFault_ = false, linked_ = false, homeContact_ = false;
  State state_ = State::Stopped;
  Stroke strokes_[AxisCount]{};
  Outputs output_;
  const char *fault_ = "-";
  Grade last_ = Grade::None;
  uint32_t counts_[AxisCount]{}, fedCount_ = 0;
  uint8_t homeAxis_ = 0, latchedIr_ = 0;
  uint32_t lastFeedLaunch_ = 0, feedBlockedAt_ = 0;
  uint32_t entered_ = 0, lastPing_ = 0, accounted_ = 0;
  uint64_t runMs_ = 0;

  bool moving() const { return state_ == State::Running || state_ == State::Homing; }

  void accountTime(uint32_t now) {
    if (state_ == State::Running) runMs_ += now - accounted_;
    accounted_ = now;
  }

  void changeState(State next, uint32_t now) {
    accountTime(now);
    state_ = next;
    entered_ = now;
  }

  void fail(const char *code, uint32_t now) {
    output_ = {};
    fault_ = code;
    changeState(State::Fault, now);
  }

  const char *readyForCommand(const Inputs &input, uint32_t now) const {
    if (input.stop) return "STOP_ACTIVE";
    if (!armed(input)) return "NOT_ARMED";
    if (!fresh(now)) return "LINK_REQUIRED";
    if (input.stations()) return "STATION_OCCUPIED";
    return nullptr;
  }

  void tickHome(const Inputs &input, uint32_t now) {
    if (input.stations()) { fail("STATION_OCCUPIED", now); return; }
    const uint8_t previous = static_cast<uint8_t>(channelMask(homeAxis_) - 1);
    if ((input.home & previous) != previous) { fail("HOME_LOST", now); return; }
    if (input.rawHome & channelMask(homeAxis_)) homeContact_ = true;
    if (input.homeAt(homeAxis_)) {
      if (++homeAxis_ == AxisCount) changeState(State::Ready, now);
      homeContact_ = false;
      entered_ = now;
    } else if (now - entered_ >= Axes[homeAxis_].returnMs) {
      fail("HOME_TIMEOUT", now);
    } else if (!homeContact_) {
      output_.servo[homeAxis_] = -1;
    }
  }

  static void beginStroke(Stroke &stroke, uint32_t now) {
    stroke = {};
    stroke.phase = Phase::Extending;
    stroke.since = now;
  }

  void finishGate(uint8_t axis) {
    const Grade grade = static_cast<Grade>(axis);
    uint32_t &total = counts_[axis];
    if (total != UINT32_MAX) ++total;
    last_ = grade;
  }

  void advance(uint8_t axis, const Inputs &input, uint32_t now) {
    auto &stroke = strokes_[axis];
    const uint8_t mask = channelMask(axis);
    const bool clear = !((input.ir | input.rawIr) & mask);
    if (stroke.phase == Phase::Extending) {
      const uint32_t elapsed = now - stroke.since;
      if (!((input.home | input.rawHome) & mask)) stroke.released = true;
      if (!stroke.released && elapsed >= ReleaseMs) { fail("HOME_NOT_RELEASED", now); return; }
      if (stroke.released && input.homeAt(axis)) { fail("HOME_REENGAGED", now); return; }
      if (elapsed < Axes[axis].extendMs) {
        output_.servo[axis] = 1;
        return;
      }
      // Reverse in the same tick that ends the outward stroke.
      stroke.phase = Phase::Retracting;
      stroke.since = now;
    }
    if (stroke.phase == Phase::Retracting) {
      // First raw contact stops the return. Confirm HOME before allowing another stroke.
      if (input.rawHome & mask) stroke.homeContact = true;
      if (input.homeAt(axis)) {
        stroke.phase = axis == Feed ? Phase::Idle : Phase::Clearing;
        stroke.since = now;
      } else if (now - stroke.since >= Axes[axis].returnMs) {
        fail("RETURN_TIMEOUT", now);
      } else if (!stroke.homeContact) {
        output_.servo[axis] = -1;
      }
    }
    if (stroke.phase == Phase::Clearing) {
      if (clear) {
        finishGate(axis);
        stroke.phase = Phase::Idle;
      } else if (now - stroke.since >= ClearMs) {
        fail("SORT_NOT_CLEAR", now);
      }
    }
  }

  void tickRun(const Inputs &input, uint32_t now) {
    const uint8_t occupied = input.ir | input.rawIr;
    const uint8_t confirmed = input.ir & input.rawIr;
    const uint8_t rising = confirmed & ~latchedIr_;
    latchedIr_ = (latchedIr_ & occupied) | confirmed;

    if (rising & FeedIr) {
      if (fedCount_ != UINT32_MAX) ++fedCount_;
      feedBlockedAt_ = now;
    }
    if ((latchedIr_ & FeedIr) && now - feedBlockedAt_ >= FeedClearMs) {
      fail("FEED_NOT_CLEAR", now);
      return;
    }

    for (uint8_t axis = 0; axis < AxisCount; ++axis) {
      const auto phase = strokes_[axis].phase;
      const uint8_t mask = channelMask(axis);
      if ((phase == Phase::Idle || phase == Phase::Clearing) && !(input.home & mask)) {
        fail("HOME_LOST", now);
        return;
      }
      if (axis == Feed) {
        if (phase == Phase::Idle && input.homeAt(axis) && !(occupied & FeedIr) &&
            now - lastFeedLaunch_ >= FeedIntervalMs) {
          beginStroke(strokes_[axis], now);
          lastFeedLaunch_ = now;
        }
      } else if (rising & mask) {
        if (phase != Phase::Idle) { fail("SORT_BUSY", now); return; }
        if (!input.homeAt(axis)) { fail("HOME_LOST", now); return; }
        beginStroke(strokes_[axis], now);
      }
      advance(axis, input, now);
      if (state_ == State::Fault) return;
    }
    output_.motor = true;
  }
};

inline const char *stateName(State state) {
  switch (state) {
    case State::Stopped: return "STOPPED";
    case State::Homing: return "HOMING";
    case State::Ready: return "READY";
    case State::Running: return "RUNNING";
    case State::Fault: return "FAULT";
  }
  return "FAULT";
}

inline const char *gradeName(Grade grade) {
  switch (grade) {
    case Grade::High: return "HIGH";
    case Grade::Mid: return "MID";
    case Grade::Low: return "LOW";
    case Grade::None: return "-";
  }
  return "-";
}
}
