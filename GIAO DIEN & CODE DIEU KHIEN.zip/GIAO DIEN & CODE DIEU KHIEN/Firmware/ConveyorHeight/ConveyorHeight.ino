#include <Arduino.h>
#include <driver/gpio.h>
#include <esp_system.h>
#include <esp_task_wdt.h>
#include "Wire.h"

#if !defined(CONFIG_IDF_TARGET_ESP32)
#error "Select ESP32 Dev Module (ESP32-WROOM-32E), with Arduino-ESP32 3.x."
#endif

namespace height {

struct DebouncedInput {
  bool raw = false, stable = false;
  uint32_t changed = 0;

  bool sample(bool value, uint32_t now) {
    if (value != raw) {
      raw = value;
      changed = now;
    }
    if (now - changed >= DebounceMs) stable = raw;
    return stable;
  }
};

static Controller controller(Commissioned);
static Inputs inputs;
static DebouncedInput irFilters[4], homeFilters[AxisCount], stopFilter;
static LineReader rx;
static uint32_t session, newestRequest, bootAt, lastTx;
static bool servoAttached[AxisCount]{}, watchdogReady, motorOn;
static uint8_t servoMotion;
static char previous[FrameSize]{};

static void readInputs(uint32_t now) {
  inputs.ir = inputs.rawIr = inputs.home = inputs.rawHome = 0;
  for (uint8_t i = 0; i < AxisCount; ++i) {
    bool ir = digitalRead(IrPins[i]) == (IrActiveHigh[i] ? HIGH : LOW);
    bool home = digitalRead(HomePins[i]) == HIGH; // KW12 COM -> GND, NC -> pin
    if (ir) inputs.rawIr |= channelMask(i);
    if (home) inputs.rawHome |= channelMask(i);
    if (irFilters[i].sample(ir, now)) inputs.ir |= channelMask(i);
    if (homeFilters[i].sample(home, now)) inputs.home |= channelMask(i);
  }
  bool stop = digitalRead(StopPin) == LOW;
  stopFilter.sample(stop, now);
  if (stop) stopFilter.stable = true;
  inputs.stop = stopFilter.stable; // Immediate assertion, debounced release.
  inputs.settled = now - bootAt >= DebounceMs;
}

static void setMotor(bool on) {
  digitalWrite(MotorPin, on ? HIGH : LOW);
  motorOn = on;
}

static bool pwm(uint8_t axis, uint16_t microseconds) {
  return ledcWrite(Axes[axis].pin, (uint32_t(microseconds) * 65536U + 10000U) / 20000U);
}

static void holdServos(bool neutral) {
  for (uint8_t i = 0; i < AxisCount; ++i) {
    if (!servoAttached[i]) continue;
    if (!pwm(i, neutral ? Axes[i].neutralUs : 0)) {
      ledcDetach(Axes[i].pin);
      gpio_set_level(static_cast<gpio_num_t>(Axes[i].pin), 0);
      pinMode(Axes[i].pin, OUTPUT);
      digitalWrite(Axes[i].pin, LOW);
      servoAttached[i] = false;
    }
  }
  servoMotion = 0;
}

static void applyOutputs(uint32_t now) {
  const Outputs &out = controller.outputs();
  if (!controller.armed(inputs)) {
    setMotor(false);
    holdServos(Commissioned && watchdogReady);
    return;
  }

  bool stop = inputs.stop || digitalRead(StopPin) == LOW;
  if (!out.motor || stop) setMotor(false);
  servoMotion = 0;
  for (uint8_t i = 0; i < AxisCount; ++i) {
    int8_t direction = stop ? 0 : out.servo[i];
    if (direction < 0 && digitalRead(HomePins[i]) == HIGH) {
      controller.latchHomeContact(i);
      direction = 0;
    }
    uint16_t pulse = direction > 0 ? Axes[i].extendUs : direction < 0 ? Axes[i].retractUs : Axes[i].neutralUs;
    if (!pwm(i, pulse)) {
      setMotor(false);
      controller.hardwareFailure("PWM_WRITE_FAILED", now);
      holdServos(true);
      return;
    }
    if (direction) servoMotion |= channelMask(i);
  }
  if (out.motor) setMotor(!stop && digitalRead(StopPin) != LOW);
}

static bool send(const char *line, int length) {
  if (length <= 0 || length >= int(FrameSize) || Serial.availableForWrite() < length) return false;
  return Serial.write(reinterpret_cast<const uint8_t *>(line), size_t(length)) == size_t(length);
}

static void sendHello() {
  char line[FrameSize];
  int length = snprintf(line, sizeof(line), "HELLO HEIGHT1 %lu\n", static_cast<unsigned long>(session));
  send(line, length);
}

static void sendState(uint32_t now, bool force = false) {
  char line[FrameSize];
  int length = formatState(line, session, controller, inputs, servoMotion, motorOn);
  if (!force && now - lastTx < StatusPeriodMs && !strcmp(line, previous)) return;
  if (send(line, length)) {
    memcpy(previous, line, size_t(length) + 1);
    lastTx = now;
  }
}

static void acceptLine(char *text, uint32_t now) {
  Frame frame = parse(text);
  if (frame.op == Operation::Invalid || (frame.op != Operation::Hello && frame.sid != session)) return;
  if (frame.op == Operation::Ping) {
    controller.ping(now);
    return;
  }
  if (frame.op == Operation::Hello) {
    newestRequest = 0;
    controller.handshake(now);
    applyOutputs(now);
    sendHello();
    sendState(now, true);
    return;
  }

  const char *reason = nullptr;
  if (frame.op == Operation::Stop) {
    controller.stop(now);
    if (frame.request > newestRequest) newestRequest = frame.request;
  } else if (frame.request <= newestRequest) {
    reason = "STALE_REQUEST";
  } else {
    newestRequest = frame.request;
    readInputs(now);
    if (Serial.availableForWrite() < 2 * int(FrameSize)) {
      reason = "TX_BUSY";
    } else {
      reason = frame.op == Operation::Home ? controller.requestHome(inputs, now) : controller.start(inputs, now);
    }
  }
  controller.tick(inputs, now);
  applyOutputs(now);
  if (!reason && frame.op != Operation::Stop && controller.state() == State::Fault)
    reason = controller.faultCode();
  char line[FrameSize];
  int length = formatReply(line, frame, reason);
  send(line, length);
  sendState(now, true);
}

static bool beginWatchdog() {
  constexpr esp_task_wdt_config_t config{WatchdogMs, 0, true};
  esp_err_t status = esp_task_wdt_init(&config);
  if (status == ESP_ERR_INVALID_STATE) status = esp_task_wdt_reconfigure(&config);
  return status == ESP_OK &&
          (esp_task_wdt_status(nullptr) == ESP_OK || esp_task_wdt_add(nullptr) == ESP_OK);
}

static void begin() {
  gpio_set_level(static_cast<gpio_num_t>(MotorPin), 0);
  pinMode(MotorPin, OUTPUT);
  setMotor(false);
  pinMode(StopPin, INPUT_PULLUP);
  for (uint8_t i = 0; i < AxisCount; ++i) {
    pinMode(IrPins[i], INPUT);          // GPIO34–39 have no internal pull-ups.
    pinMode(HomePins[i], INPUT_PULLUP);
    pinMode(Axes[i].pin, OUTPUT);
    digitalWrite(Axes[i].pin, LOW);
    servoAttached[i] = ledcAttachChannel(Axes[i].pin, 50, 16, i);
    if (!servoAttached[i]) controller.hardwareFailure("PWM_INIT_FAILED", millis());
  }
  holdServos(false);
  watchdogReady = beginWatchdog();
  if (!watchdogReady) controller.hardwareFailure("WDT_INIT_FAILED", millis());
  Serial.setTxBufferSize(1024);
  Serial.begin(Baud, SERIAL_8N1);
  session = esp_random();
  if (!session) session = 1;
  bootAt = millis();
  sendHello();
}

static void poll() {
  uint32_t now = millis();
  if (watchdogReady && esp_task_wdt_reset() != ESP_OK) {
    watchdogReady = false;
    controller.hardwareFailure("WDT_RESET_FAILED", now);
  }
  readInputs(now);
  controller.tick(inputs, now);
  applyOutputs(now);
  for (int budget = 96; budget > 0 && Serial.available() > 0; --budget) {
    int byte = Serial.read();
    if (byte < 0) break;
    if (char *line = rx.push(static_cast<char>(byte))) acceptLine(line, millis());
  }
  sendState(millis());
  delay(2);
}
}

void setup() { height::begin(); }
void loop() { height::poll(); }
