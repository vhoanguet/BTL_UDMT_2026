#pragma once
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include "Controller.h"

namespace height {
constexpr size_t FrameSize = 160;

enum class Operation { Invalid, Hello, Ping, Home, Start, Stop };

struct Frame {
  Operation op = Operation::Invalid;
  uint32_t sid = 0, request = 0;
};

class LineReader {
public:
  char *push(char byte) {
    if (byte == '\n') {
      bool valid = !discard_ && used_ != 0;
      if (used_ && text_[used_ - 1] == '\r') --used_;
      text_[used_] = '\0';
      used_ = 0;
      discard_ = false;
      return valid ? text_ : nullptr;
    }
    if (discard_) return nullptr;
    if (used_ == sizeof(text_) - 1 || (byte != '\r' && (byte < ' ' || byte > '~')))
      discard_ = true;
    else
      text_[used_++] = byte;
    return nullptr;
  }

private:
  char text_[241]{};
  size_t used_ = 0;
  bool discard_ = false;
};

inline bool number(const char *text, uint32_t &out) {
  if (!*text) return false;
  out = 0;
  for (; *text; ++text) {
    if (*text < '0' || *text > '9') return false;
    uint32_t digit = *text - '0';
    if (out > (UINT32_MAX - digit) / 10U) return false;
    out = 10U * out + digit;
  }
  return true;
}

inline Frame parse(char *line) {
  char *words[4]{};
  size_t count = 0;
  while (*line) {
    while (*line == ' ') ++line;
    if (!*line) break;
    if (count == 4) return {};
    words[count++] = line;
    while (*line && *line != ' ') ++line;
    if (*line) *line++ = '\0';
  }
  if (count == 2 && !strcmp(words[0], "HELLO") && !strcmp(words[1], "HEIGHT1"))
    return {Operation::Hello};
  Frame frame;
  if (count < 2 || !number(words[1], frame.sid) || frame.sid == 0) return {};
  if (count == 2 && !strcmp(words[0], "PING")) {
    frame.op = Operation::Ping;
    return frame;
  }
  if (count != 4 || strcmp(words[0], "CMD") || !number(words[2], frame.request) || frame.request == 0)
    return {};
  if (!strcmp(words[3], "HOME")) frame.op = Operation::Home;
  else if (!strcmp(words[3], "START")) frame.op = Operation::Start;
  else if (!strcmp(words[3], "STOP")) frame.op = Operation::Stop;
  return frame;
}

inline const char *opName(Operation op) {
  switch (op) {
    case Operation::Home: return "HOME";
    case Operation::Start: return "START";
    case Operation::Stop: return "STOP";
    default: return "";
  }
}

inline int formatState(char (&line)[FrameSize], uint32_t sid, const Controller &ctrl,
                       const Inputs &input, uint8_t servoMask, bool motor) {
  return snprintf(line, sizeof(line), "STATE %lu %s %lu %lu %lu %u %u %u %u %u %u %lu %s %s %lu\n",
    static_cast<unsigned long>(sid), stateName(ctrl.state()),
    static_cast<unsigned long>(ctrl.count(Grade::High)), static_cast<unsigned long>(ctrl.count(Grade::Mid)),
    static_cast<unsigned long>(ctrl.count(Grade::Low)), unsigned(input.ir), unsigned(input.home),
    unsigned(servoMask), unsigned(motor), unsigned(input.stop), unsigned(ctrl.armed(input)),
    static_cast<unsigned long>(ctrl.runSeconds()), gradeName(ctrl.lastGrade()), ctrl.faultCode(),
    static_cast<unsigned long>(ctrl.fedCount()));
}

inline int formatReply(char (&line)[FrameSize], const Frame &frame, const char *reason) {
  auto sid = static_cast<unsigned long>(frame.sid);
  auto rid = static_cast<unsigned long>(frame.request);
  if (reason) return snprintf(line, sizeof(line), "ERR %lu %lu %s %s\n", sid, rid, opName(frame.op), reason);
  return snprintf(line, sizeof(line), "ACK %lu %lu %s\n", sid, rid, opName(frame.op));
}
}
