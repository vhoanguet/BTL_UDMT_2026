# Firmware ESP32 phân loại theo chiều cao

Sketch [ConveyorHeight.ino](ConveyorHeight/ConveyorHeight.ino) dành cho ESP32-WROOM-32E trên **PCB BANG TAI – JDC** và **PCB BANG TAI – KF2**. Firmware dùng Arduino-ESP32 3.x, giao tiếp USB–UART qua CH340 và gửi dữ liệu trực tiếp tới WinForms theo [HEIGHT1](../GIAO_THUC_COM.md).

## Gán chân

Chân được đối chiếu theo net và pad U1 trên schematic/layout của hai bản PCB BANG TAI, rồi quy đổi theo [pinout ESP32-WROOM-32E](https://documentation.espressif.com/esp32-wroom-32e_esp32-wroom-32ue_datasheet_en.html).

| Net | GPIO | Vị trí và chức năng |
| --- | ---: | --- |
| IR 1 | 36 | H5. Đặt sau ống cấp, đếm phôi đã lên băng |
| IR 2 | 39 | H7. Trạm gạt phôi cao |
| IR 3 | 34 | H6. Trạm gạt phôi trung |
| IR 4 | 35 | H8. Trạm gạt phôi thấp ở cuối băng |
| SERVO 1 | 25 | JP2 pad 3. MG996R 360° cấp phôi |
| SERVO 2 | 26 | JP2 pad 2. MG90S 360° gạt cao theo IR2 |
| SERVO 3 | 27 | JP2 pad 1. MG90S 360° gạt trung theo IR3 |
| SERVO 4 | 32 | JP2 pad 4. MG90S 360° gạt thấp theo IR4 |
| LIMIT 1–4 | 4, 5, 18, 19 | H1–H4, pad 2. KW12 tương ứng với bốn servo |
| BUTTON | 33 | SW1, kéo lên nội, nhấn nối GND. STOP phần mềm |
| MOSFET | 23 | Mức cao bật tầng PC817/Q1 của động cơ, KF1 là đầu ra tải |
| TX_0 / RX_0 | 1 / 3 | CH340, 115200 baud, 8N1 |

### PCB IR Sensor và các ngõ vào

- **Cáp IR.** Trên PCB IR Sensor, J1 pad 1 là **+5 V**, pad 2 **GND**, pad 3 **OUT**. Trên PCB BANG TAI, H5–H8 pad 1 là **tín hiệu IR**, pad 2 **GND**, pad 3 **+5 V**. Đấu đúng net từng đầu và xác nhận mức logic trước khi nối OUT tới ESP32.
- **Mức logic IR.** Sơ đồ dùng LM358 cấp 5 V, ngõ OUT qua R3 330 Ω và có LED D3. Đây là mạch báo, không có tầng chuyển mức 3,3 V riêng. Sau khi giao tiếp mức phù hợp, đo cả hai trạng thái có phôi và trống ở phía ESP32. Dùng mức đó để đặt `IrActiveHigh[]` trong [Config.h](ConveyorHeight/Config.h). Cả bốn GPIO IR thuộc nhóm input-only và thiếu điện trở kéo nội. Bảo đảm tín hiệu có mức xác định khi vận hành. [LM358 – TI](https://www.ti.com/lit/ds/symlink/lm358.pdf) · [GPIO ESP32 – Espressif](https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-reference/peripherals/gpio.html)
- **KW12.** Cấu hình theo phương án COM → GND (pad 1 H1–H4), NC → LIMIT (pad 2). Nhả công tắc đọc LOW, chạm chốt đọc HIGH. Kiểm tra từng cặp nhả/chạm và boot với công tắc đã nối. Mạch NC này có thể báo giống chạm HOME khi đứt dây.

### Tầng công suất

Firmware dùng GPIO23 **bật/tắt**. Hai PCB BANG TAI hiện dùng PC817 kéo gate Q1 từ VCC qua R5, với R6 kéo gate xuống GND. Cần xử lý và kiểm tra phần công suất trước khi cấp 24 V, đặc biệt giới hạn VGS, package Q1, diode hồi tiếp, khả năng chịu dòng kẹt và bộ hạ áp. Báo cáo rà soát trước đó ghi VGS có thể tới khoảng 21,6 V theo mô hình tĩnh, trong khi IRF3205PbF có giới hạn tuyệt đối ±20 V. JP2/JP1 dùng cùng đường +5 V/GND của bo theo schematic. Xác nhận nguồn servo đáp ứng dòng xung và sụt áp khi tải trước khi vận hành. [Rà soát tầng động cơ](../../outputs/Altium_review_20261118/Tuong_thich_dong_co_24V_22RPM.md) · [IRF3205PbF – Infineon](https://www.infineon.com/assets/row/public/documents/24/49/infineon-irf3205-datasheet-en.pdf)

SW1, STOP qua COM và watchdog ngắt **lệnh điều khiển**. Cắt công suất độc lập thuộc phần cứng.

## Trình tự đã triển khai

1. Kết nối WinForms, **Về gốc** để thu từng servo đến KW12. Firmware ngừng phát lệnh thu ngay khi thấy công tắc tác động và chỉ chuyển bước khi tín hiệu đã ổn định.
2. **Chạy máy** bật băng tải và chạy nhịp đầu của S1. S1 đẩy phôi trực tiếp từ ống lên băng trong 450 ms, rồi thu đến KW12 số 1. Firmware đặt nhịp cấp **5 giây**, tính từ lúc bắt đầu lần đẩy trước. S1 bắt đầu lần tiếp theo khi đủ 5 giây, đã về gốc và IR1 đã thoáng. Mỗi lần IR1 chuyển từ thoáng sang bị chắn và giữ ổn định 20 ms thì bộ đếm **Đã cấp** tăng một.
3. Theo chiều chuyển động của băng, các module IR2, IR3 và IR4 đặt trước thanh đẩy tương ứng **5 cm** theo bố trí thực tế. Khi IR được xác nhận bị chắn sau 20 ms lọc tín hiệu, servo của trạm nhận lệnh đẩy trong cùng lượt xử lý. Thời gian đo thực tế để thanh gạt đi hết chiều rộng băng là **1,2 giây**, được dùng làm thời gian đẩy cho S2–S4. Hết thời gian đẩy, servo đảo chiều ngay. Khi KW12 tác động, firmware ngừng lệnh thu và chờ xác nhận HOME ổn định để tránh chạy lại do dội tiếp điểm.
4. Băng tải chạy xuyên suốt khi cấp, gạt và thu. Các trạm có thể chạy đồng thời. Một lượt phân loại được tính khi servo tương ứng đã về gốc và tia IR đã thoáng. Số đếm này phản ánh chu trình đã hoàn thành; hệ thống chưa có tín hiệu phản hồi ở máng.
5. Firmware dừng động cơ và servo khi có STOP, mất heartbeat hoặc lỗi vận hành. Hai phôi đến cùng trạm khi servo chưa sẵn sàng sẽ báo `SORT_BUSY`. Có giới hạn thời gian về gốc, thời gian nhả IR1 và thời gian IR trạm gạt nhả. Sau khi xử lý lỗi và lấy phôi còn trên băng, bấm **Dừng máy → Về gốc → Chạy máy**. Lỗi khởi tạo/ghi PWM hoặc watchdog giữ khóa đến khi khởi động lại sau khi xử lý nguyên nhân.

## Biên dịch và kiểm tra

- Mở `ConveyorHeight/ConveyorHeight.ino` bằng Arduino IDE, chọn **ESP32 Dev Module** thuộc Arduino-ESP32 3.x. Không cần thư viện servo ngoài. Có thể dùng `arduino-cli compile --fqbn esp32:esp32:esp32 ConveyorHeight`.
- Trên máy này, trình biên dịch ESP32 gặp lỗi với đường dẫn dự án có dấu. Bản kiểm tra được biên dịch từ bản sao nguyên thư mục `ConveyorHeight` trong đường dẫn tạm không dấu.
- [Config.h](ConveyorHeight/Config.h) phát hành với `Commissioned = false`. Chế độ này đọc IR, KW12 và SW1, giao tiếp WinForms và báo `armed=0`. GPIO23 ở LOW và servo không nhận xung điều khiển. Kiểm tra tín hiệu và phần công suất, xung trung tính, chiều quay, hành trình S1 và thời gian thu. Khi kiểm tra chu trình trên băng thật, quan sát thời điểm thanh gạt chạm phôi ở tốc độ băng sử dụng với vị trí IR cách thanh đẩy 5 cm.
- [ControllerTests.cpp](Tests/ControllerTests.cpp) kiểm tra bộ điều khiển độc lập phần cứng và định dạng UART, dùng C++17. Ví dụ từ Developer Command Prompt, chạy `cl /nologo /EHsc /std:c++17 Tests\ControllerTests.cpp` rồi `ControllerTests.exe`.

Đã biên dịch với Arduino-ESP32 3.3.12 cho `esp32:esp32:esp32`. Kiểm thử trên máy tính gồm chu trình cấp và gạt đồng thời, thời điểm đảo chiều, dội công tắc KW12, STOP, mất liên lạc và giao thức WinForms. Chưa nạp firmware hoặc thử với bo, cảm biến và cơ cấu thật.
