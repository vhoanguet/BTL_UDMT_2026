#include "../ConveyorHeight/Wire.h"
#include <cstdlib>

using namespace height;

static int checks = 0;
#define CHECK(condition) do {                                                   \
  if (!(condition)) { fprintf(stderr, "Line %d: %s\n", __LINE__, #condition);   \
                       std::exit(1); }                                           \
  ++checks;                                                                      \
} while (false)

struct Rig {
  Controller ctrl{true};
  Inputs in{0, 0, AllHome, AllHome, false, true};
  uint32_t now = 100;

  void tick(uint32_t advance = 1, bool keepLink = true) {
    now += advance;
    if (keepLink) ctrl.ping(now);
    ctrl.tick(in, now);
  }

  void ir(uint8_t mask) { in.ir = in.rawIr = mask; }
  void home() {
    ctrl.ping(now);
    CHECK(ctrl.requestHome(in, now) == nullptr);
    for (int i = 0; i < AxisCount; ++i) tick();
    CHECK(ctrl.state() == State::Ready);
  }
  void start() {
    home();
    CHECK(ctrl.start(in, now) == nullptr);
  }
  void checkMotion(int axis, int direction) {
    for (int i = 0; i < AxisCount; ++i)
      CHECK(ctrl.outputs().servo[i] == (i == axis ? direction : 0));
  }
  void release(uint8_t mask) { in.home = in.rawHome = static_cast<uint8_t>(AllHome & ~mask); }
  void finishFeed() {
    release(channelMask(Feed));
    tick(Axes[Feed].extendMs);
    checkMotion(Feed, -1);
    CHECK(ctrl.outputs().motor);
    release(0);
    tick();
    checkMotion(-1, 0);
    CHECK(ctrl.outputs().motor);
  }
  void fault(const char *code) {
    CHECK(ctrl.state() == State::Fault);
    CHECK(!strcmp(ctrl.faultCode(), code));
    CHECK(!ctrl.outputs().motor);
    checkMotion(-1, 0);
  }
};

static void feed() {
  constexpr uint32_t expectedFeedIntervalMs = 5000;
  Rig r;
  r.start();
  r.tick();
  CHECK(r.ctrl.outputs().motor);
  r.checkMotion(Feed, 1);
  CHECK(r.ctrl.fedCount() == 0);
  const uint32_t launched = r.now;
  r.in.rawIr = FeedIr;
  r.tick();
  CHECK(r.ctrl.fedCount() == 0);
  r.ir(FeedIr);
  r.tick();
  CHECK(r.ctrl.fedCount() == 1);
  r.in.rawIr = 0;
  r.tick();
  r.ir(FeedIr);
  r.tick();
  CHECK(r.ctrl.fedCount() == 1);
  r.ir(0);
  r.finishFeed();
  r.tick(launched + expectedFeedIntervalMs - r.now - 1);
  CHECK(r.ctrl.outputs().motor && r.ctrl.runSeconds() == 5);
  r.checkMotion(-1, 0);
  r.tick();
  r.checkMotion(Feed, 1);
  CHECK(r.ctrl.outputs().motor && r.ctrl.fedCount() == 1);
  r.ir(FeedIr);
  r.tick();
  CHECK(r.ctrl.fedCount() == 2);
}

static void classify(Grade grade, Axis axis) {
  Rig r;
  r.start();
  r.tick();
  r.finishFeed();
  const auto mask = channelMask(axis);
  r.in.rawIr = mask;
  r.tick();
  r.checkMotion(-1, 0);
  r.ir(mask);
  r.tick();
  CHECK(r.ctrl.outputs().motor);
  r.checkMotion(axis, 1);
  r.release(mask);
  r.tick(1199);
  r.checkMotion(axis, 1);
  CHECK(r.ctrl.outputs().motor);
  CHECK(r.ctrl.count(grade) == 0);
  r.tick();
  r.checkMotion(axis, -1);
  CHECK(r.ctrl.outputs().motor);

  r.in.rawHome = AllHome;
  r.tick();
  r.checkMotion(-1, 0);
  r.release(mask);
  r.tick();
  r.checkMotion(-1, 0);
  r.release(0);
  r.tick();
  CHECK(r.ctrl.count(grade) == 0);
  CHECK(r.ctrl.outputs().motor);
  r.ir(0);
  r.tick();
  CHECK(r.ctrl.count(grade) == 1 && r.ctrl.lastGrade() == grade);
  r.tick();
  CHECK(r.ctrl.count(grade) == 1 && r.ctrl.outputs().motor);
  r.ir(mask);
  r.tick();
  r.checkMotion(axis, 1);
  CHECK(r.ctrl.count(grade) == 1 && r.ctrl.outputs().motor);
}

static void concurrentGates() {
  Rig r;
  r.start();
  r.tick();
  r.finishFeed();
  r.ir(channelMask(HighGate));
  r.tick();
  r.release(channelMask(HighGate));
  r.ir(channelMask(HighGate) | channelMask(MidGate) | channelMask(LowGate));
  r.tick(100);
  for (uint8_t axis = HighGate; axis < AxisCount; ++axis)
    CHECK(r.ctrl.outputs().servo[axis] == 1);
  r.release(StationIrs);
  r.tick(1100);
  CHECK(r.ctrl.outputs().motor);
  CHECK(r.ctrl.outputs().servo[HighGate] == -1);
  CHECK(r.ctrl.outputs().servo[MidGate] == 1);
  CHECK(r.ctrl.outputs().servo[LowGate] == 1);
  r.ctrl.latchHomeContact(HighGate); // Contact detected while applying PWM.
  r.tick(100);
  CHECK(r.ctrl.outputs().motor);
  CHECK(r.ctrl.outputs().servo[HighGate] == 0);
  CHECK(r.ctrl.outputs().servo[MidGate] == -1);
  CHECK(r.ctrl.outputs().servo[LowGate] == -1);
  r.release(0);
  r.ir(0);
  r.tick();
  for (uint8_t grade = HighGate; grade < AxisCount; ++grade)
    CHECK(r.ctrl.count(static_cast<Grade>(grade)) == 1);
  CHECK(r.ctrl.fedCount() == 0 && r.ctrl.outputs().motor);
  r.checkMotion(-1, 0);
}

static void interlocks() {
  Rig r;
  Controller locked{false};
  locked.ping(r.now);
  CHECK(!locked.armed(r.in));
  CHECK(!strcmp(locked.requestHome(r.in, r.now), "NOT_ARMED"));
  CHECK(!strcmp(r.ctrl.requestHome(r.in, r.now), "LINK_REQUIRED"));
  r.ctrl.ping(r.now);
  r.ir(channelMask(MidGate));
  CHECK(!strcmp(r.ctrl.requestHome(r.in, r.now), "STATION_OCCUPIED"));
  r.ir(0);
  r.home();
  r.ir(FeedIr);
  CHECK(!strcmp(r.ctrl.start(r.in, r.now), "FEED_OCCUPIED"));
  r.ir(0);
  CHECK(r.ctrl.start(r.in, r.now) == nullptr);
  r.tick();
  r.ir(channelMask(HighGate));
  r.tick();
  CHECK(r.ctrl.outputs().servo[Feed] == 1 && r.ctrl.outputs().servo[HighGate] == 1);
  r.in.stop = true;
  r.tick();
  CHECK(r.ctrl.state() == State::Stopped && !r.ctrl.outputs().motor);
  r.checkMotion(-1, 0);
  CHECK(!strcmp(r.ctrl.start(r.in, r.now), "STOP_ACTIVE"));
  r.in.stop = false;
  r.ir(0);
  r.tick();
  CHECK(!strcmp(r.ctrl.start(r.in, r.now), "NOT_READY"));

  r.start();
  r.tick();
  r.tick(LinkTimeoutMs, false);
  r.fault("PC_LINK_LOST");
  r.tick();
  r.fault("PC_LINK_LOST");
  r.ctrl.stop(r.now);
  CHECK(r.ctrl.state() == State::Stopped);
  r.start();
  r.ctrl.handshake(r.now);
  CHECK(r.ctrl.state() == State::Stopped && !r.ctrl.fresh(r.now));
  r.ctrl.hardwareFailure("PWM_WRITE_FAILED", r.now);
  r.ctrl.stop(r.now);
  r.fault("PWM_WRITE_FAILED");
  CHECK(!r.ctrl.armed(r.in));
}

static void faults() {
  Rig homing;
  homing.release(AllHome);
  homing.ctrl.ping(homing.now);
  CHECK(homing.ctrl.requestHome(homing.in, homing.now) == nullptr);
  homing.tick();
  homing.checkMotion(Feed, -1);
  homing.ctrl.latchHomeContact(Feed);
  homing.tick();
  homing.checkMotion(-1, 0);
  homing.tick(Axes[Feed].returnMs);
  homing.fault("HOME_TIMEOUT");

  Rig noRelease;
  noRelease.start();
  noRelease.tick();
  noRelease.tick(ReleaseMs);
  noRelease.fault("HOME_NOT_RELEASED");

  Rig returnFault;
  returnFault.start();
  returnFault.tick();
  returnFault.release(channelMask(Feed));
  returnFault.tick(Axes[Feed].extendMs);
  returnFault.checkMotion(Feed, -1);
  returnFault.tick(Axes[Feed].returnMs);
  returnFault.fault("RETURN_TIMEOUT");

  Rig feedBlocked;
  feedBlocked.start();
  feedBlocked.tick();
  feedBlocked.ir(FeedIr);
  feedBlocked.tick();
  feedBlocked.finishFeed();
  feedBlocked.tick(FeedClearMs);
  feedBlocked.fault("FEED_NOT_CLEAR");
  CHECK(feedBlocked.ctrl.fedCount() == 1);

  Rig busy;
  busy.start();
  busy.tick();
  busy.finishFeed();
  busy.ir(channelMask(HighGate));
  busy.tick();
  busy.release(channelMask(HighGate));
  busy.ir(0);
  busy.tick(50);
  busy.ir(channelMask(HighGate));
  busy.tick();
  busy.fault("SORT_BUSY");

  Rig blocked;
  blocked.start();
  blocked.tick();
  blocked.finishFeed();
  blocked.ir(channelMask(LowGate));
  blocked.tick();
  blocked.release(channelMask(LowGate));
  blocked.tick(GateExtendMs);
  blocked.release(0);
  blocked.tick();
  blocked.tick(ClearMs);
  blocked.fault("SORT_NOT_CLEAR");
  CHECK(blocked.ctrl.count(Grade::Low) == 0);
}

static Frame read(LineReader &reader, const char *bytes) {
  for (; *bytes; ++bytes)
    if (char *line = reader.push(*bytes)) return parse(line);
  return {};
}

static void wire() {
  LineReader reader;
  CHECK(read(reader, "HELLO HEIGHT1\r\n").op == Operation::Hello);
  CHECK(read(reader, "PING 99\n").op == Operation::Ping);
  Frame frame = read(reader, "CMD 4294967295 4294967295 START\n");
  CHECK(frame.op == Operation::Start && frame.sid == UINT32_MAX && frame.request == UINT32_MAX);
  CHECK(read(reader, "CMD 4294967296 3 HOME\n").op == Operation::Invalid);
  CHECK(read(reader, "CMD 99 -1 HOME\n").op == Operation::Invalid);
  CHECK(read(reader, "CMD 99 0 STOP\n").op == Operation::Invalid);
  CHECK(read(reader, "CMD 99 1 START extra\n").op == Operation::Invalid);
  CHECK(read(reader, "CMD 99 1 STA\rRT\n").op == Operation::Invalid);
  for (int i = 0; i < 320; ++i) reader.push(' ');
  CHECK(read(reader, "CMD 99 1 START\n").op == Operation::Invalid);
  CHECK(read(reader, "CMD 99 11 STOP\n").op == Operation::Stop);
  char line[FrameSize];
  formatReply(line, frame, nullptr);
  CHECK(!strcmp(line, "ACK 4294967295 4294967295 START\n"));
  formatReply(line, frame, "NOT_READY");
  CHECK(!strcmp(line, "ERR 4294967295 4294967295 START NOT_READY\n"));
  Rig r;
  r.home();
  formatState(line, 99, r.ctrl, r.in, 0, false);
  CHECK(!strcmp(line, "STATE 99 READY 0 0 0 0 15 0 0 0 1 0 - - 0\n"));
  CHECK(r.ctrl.start(r.in, r.now) == nullptr);
  r.ir(FeedIr);
  r.tick();
  formatState(line, 99, r.ctrl, r.in, 0, true);
  CHECK(!strcmp(line, "STATE 99 RUNNING 0 0 0 1 15 0 1 0 1 0 - - 1\n"));
}

int main() {
  feed();
  classify(Grade::High, HighGate);
  classify(Grade::Mid, MidGate);
  classify(Grade::Low, LowGate);
  concurrentGates();
  interlocks();
  faults();
  wire();
  printf("%d firmware assertions passed\n", checks);
}
