namespace BangTai_ChieuCao;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        using var dashboard = new Dashboard();
        if (args is ["--preview", var path])
        {
            dashboard.SavePreview(path);
            return;
        }
        if (args is ["--preview", var sizedPath, var dimensions] &&
            dimensions.Split('x') is [var w, var h] &&
            int.TryParse(w, out int width) && int.TryParse(h, out int height) && width > 0 && height > 0)
        {
            dashboard.SavePreview(sizedPath, new Size(width, height));
            return;
        }

        Application.Run(dashboard);
    }
}
