# Băng tải phân loại chiều cao

Giao diện WinForms cho PCB BANG TAI, gồm kết nối ESP32, điều khiển, số phôi **Đã cấp** qua IR1, bộ đếm Cao / Trung / Thấp, biểu đồ tỷ lệ và nhật ký UTC+7. Ô **Tổng** cộng ba loại đã phân loại.

## Mở và kết nối

1. Mở `bin/Release/net8.0-windows/BangTai_ChieuCao.exe` trên Windows có .NET 8 Desktop Runtime. Giữ nguyên các tệp đi cùng EXE.
2. Với bo đã nạp [firmware HEIGHT1](Firmware/README.md), cắm USB–UART, bấm **Quét**, chọn COM rồi bấm **Kết nối ESP32**. Giao thức ở [GIAO_THUC_COM.md](GIAO_THUC_COM.md).
3. Chọn **Về gốc**. Khi bốn đèn KW12 chuyển xanh và trạng thái hiện **Sẵn sàng**, chọn **Chạy máy**.
4. Chọn **Dừng máy** để gửi lệnh dừng qua COM. **Reset bộ đếm** đặt mốc thống kê cho lần kết nối hiện tại trên máy tính. **Xuất CSV** lưu nhật ký, **Xuất báo cáo** lưu thống kê và nhật ký sang HTML.

Mở `BangTai_ChieuCao.csproj` bằng Visual Studio với workload .NET desktop development. Có thể biên dịch bằng `dotnet build BangTai_ChieuCao.csproj -c Release`.

## Tín hiệu và phạm vi

Hai bản PCB BANG TAI JDC và KF2 có cùng tên net cho USB–UART, IR 1–4, LIMIT 1–4, SERVO 1–4, BUTTON và ngõ động cơ MOSFET. Màn hình hiển thị tín hiệu logic firmware đã chuẩn hóa.

| Ngõ trên PCB | Vai trò hiển thị dự kiến |
| --- | --- |
| IR 1 | Đếm phôi sau ống cấp, khi đã lên băng |
| IR 2 | Phát hiện phôi loại cao |
| IR 3 | Phát hiện phôi loại trung |
| IR 4 | Phát hiện phôi loại thấp ở cuối băng tải |
| LIMIT 1–4 | Bốn KW12 báo về gốc |
| SERVO 1–4 | Cấp phôi, gạt cao, gạt trung, gạt thấp |
| BUTTON | Nút vật lý trên bo, dự kiến dùng làm ngõ vào STOP |
| MOSFET | Tín hiệu điều khiển đầu ra động cơ băng tải |

Đèn **Động cơ băng** sáng xanh khi ESP32 báo đã bật đầu ra điều khiển động cơ. Đèn này hiển thị lệnh điều khiển, không có phản hồi tốc độ từ động cơ. Đèn **Ngõ STOP** sáng xanh khi ESP32 báo tín hiệu dừng vật lý đang tác động. Nút **Dừng máy** trên ứng dụng gửi một lệnh dừng riêng qua COM.

Đèn servo hiển thị lệnh chuyển động từ ESP32. Đèn KW12 hiển thị phản hồi công tắc. Khi chạy, S1 lặp chu trình cấp phôi và mỗi trạm gạt phản ứng với IR riêng trong lúc băng tải tiếp tục chạy. **Reset bộ đếm** đặt chung mốc cho số đếm cấp và số đếm phân loại. Nếu kết nối firmware cũ, ứng dụng hiển thị tên servo theo firmware đó và dấu gạch ở ô **Đã cấp**.

Firmware `HEIGHT1` đi kèm mặc định chỉ đọc tín hiệu và cho phép kết nối. Các bước đối chiếu chân, hiệu chỉnh cơ khí và mở khóa chuyển động nằm trong [hướng dẫn firmware](Firmware/README.md).
